using LiteDB;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Newtonsoft.Json;
using System.Net;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace MountCarmelweb
{
    public class Program
    {
        public static string apppath { get; set; }
        public static void Main(string[] args)
        {

            //ReplaceBarcode();
            //ReplacePrefix();
            //ReplaceFACodeinFAInv();
            //DeleteItemMaster();
            var builder = WebApplication.CreateBuilder(args);
            
            // Add services to the container.
            builder.Services.AddControllersWithViews();
            builder.Services.AddControllers()
                .AddXmlSerializerFormatters();
            builder.Services.AddMvc().AddMvcOptions(options =>
            {
                options.MaxValidationDepth = 999;   //https://stackoverflow.com/questions/63112368/asp-net-core-api-validationvisitor-exceeded-the-maximum-configured-validation
            });
            //var ipAddress = IPAddress.Parse("192.168.0.100");
            /*builder.WebHost.ConfigureKestrel(options =>
            {
                //options.Listen(ipAddress, 4563, listenOptions =>
                options.ListenLocalhost(4563, listenOptions =>
                {
                    listenOptions.UseHttps();
                });
            });*/

           var app = builder.Build();
           System.IO.Directory.CreateDirectory(Path.Combine(app.Environment.WebRootPath, "Data"));
            // Configure the HTTP request pipeline.
           if (!app.Environment.IsDevelopment())
           {
               app.UseExceptionHandler("/Home/Error");
               // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
               app.UseHsts();
           }
            
            //app.UseHttpsRedirection();
           app.UseStaticFiles();
            
           app.UseRouting();
            
           app.UseAuthorization();

           app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");
           apppath = Path.Combine(app.Environment.WebRootPath, @"Data\");
            //string cpath = Path.Combine(app.Environment.WebRootPath, "Data");
            app.UseExceptionHandler("/Home/Error"); // This handles exceptions 
            app.UseDeveloperExceptionPage(); // This should come later
            Console.WriteLine(apppath);
           Console.WriteLine(int.Parse(DateTime.Now.ToString("yyyyMMdd")) + Environment.NewLine + AppContext.BaseDirectory);


            //var host = new WebHostBuilder().UseUrls("https://localhost:4581/").UseConfiguration(builder);
            
            app.Run();


        }
        public static void ReplaceBarcode()
        {
            Console.WriteLine(File.Exists(@"D:\TDD\BrajeshBhai\invsft_23-12-24\Data\003\sipl.tdd"));

                
            using (var db = new LiteDatabase(@"Filename=D:\TDD\BrajeshBhai\invsft_23-12-24\Data\003\SIPL.tdd;connection=shared;"))
            {
                var locs = db.GetCollection<Asset>("assets");

                // Get all assets from the database where Barcode contains "_"
                IList<Asset> assetsToUpdate = locs.Find(x => !string.IsNullOrEmpty(x.Barcode) && x.Barcode.Contains("_")).ToList();

                // Replace and update barcodes in batch
                foreach (var asset in assetsToUpdate)
                {
                    asset.Barcode = asset.Barcode.Replace("_", "-");
                }

                // Use Upsert to update all at once
                locs.Update(assetsToUpdate);

                Console.WriteLine($"{assetsToUpdate.Count} barcodes updated successfully.");
            }

            
        }
        public static void ReplacePrefix()
        {
            Console.WriteLine(File.Exists(@"D:\TDD\BrajeshBhai\invsft_23-12-24\Data\001\sipl.tdd"));
            using (var db = new LiteDatabase(@"Filename=D:\TDD\BrajeshBhai\invsft_23-12-24\Data\001\SIPL.tdd;connection=shared;"))
            {
                var itemswithprefix = db.GetCollection<Item>("items");
                List<Item> itemsToUpdate = itemswithprefix.Find(x => !string.IsNullOrEmpty(x.prefix) && x.prefix.Contains("_")).ToList();
                
                foreach (var asset in itemsToUpdate)
                {
                    asset.prefix = asset.prefix.Replace("_", "-");
                }

                // Use Upsert to update all at once
                itemswithprefix.Update(itemsToUpdate);

                Console.WriteLine($"{itemsToUpdate.Count} barcodes updated successfully.");
            }
        }
        public static void ReplaceFACodeinFAInv()
        {

            Console.WriteLine(File.Exists(@"D:\TDD\BrajeshBhai\MCS_Data_28-Dec-2024\003\sipl.tdd"));
            using (var db = new LiteDatabase(@"Filename=D:\TDD\BrajeshBhai\MCS_Data_28-Dec-2024\003\SIPL.tdd;connection=shared;"))
            {

                var invoiceCollection = db.GetCollection<Invoice>("fainvoices");

                // Use a query to fetch only the invoices where replacement is necessary
                var invoicesToUpdate = invoiceCollection.FindAll()
                    .Where(invoice => invoice.invoiceitems != null &&
                                      invoice.invoiceitems.Any(item => !string.IsNullOrEmpty(item.itemname) && item.itemname.Contains("_")))
                    .ToList();
                int f =0;
                foreach (var invoice in invoicesToUpdate)
                {
                    bool isUpdated = false;

                    foreach (var item in invoice.invoiceitems)
                    {
                        if (!string.IsNullOrEmpty(item.itemname) && item.itemname.Contains("_"))
                        {
                            item.itemname = item.itemname.Replace("_", "-");
                            isUpdated = true;
                        }
                    }

                    // Update only if any item was modified
                    if (isUpdated)
                    {
                        invoiceCollection.Update(invoice);
                    }
                    f++;
                }

                Console.WriteLine($"{f} Update complete. Underscores replaced with hyphens where needed.");
            }

        }
        private static void DeleteItemMaster()
        {
            Console.WriteLine(File.Exists(@"D:\VisualStudioProjects\SinglePageApplication\MountCarmel\MountCarmelweb\wwwroot\Data\003\SIPL.tdd"));
            using (var db = new LiteDatabase(@"Filename=D:\VisualStudioProjects\SinglePageApplication\MountCarmel\MountCarmelweb\wwwroot\Data\003\SIPL.tdd;connection=shared;"))
            {
                var invoiceCollection = db.GetCollection<Invoice>("fainvoices");
                var invoicesToUpdate = invoiceCollection.FindAll()
                    .Where(invoice => invoice.invoiceitems != null &&
                                      invoice.invoiceitems.Any(item => !string.IsNullOrEmpty(item.itemname) && item.itemid == 341))
                    .ToList();
                foreach (var invoice in invoicesToUpdate)
                {
                    Console.WriteLine(JsonConvert.SerializeObject(invoice));
                }
            }
        }

    }
}