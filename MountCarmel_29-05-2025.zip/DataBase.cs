﻿using LiteDB;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using System.Xml.Serialization;
using System.Xml;
using Microsoft.AspNetCore.Components.Forms;
using System.Globalization;
using System.Collections.Generic;
using NuGet.ContentModel;
using Humanizer;
using Windows.UI.ViewManagement;
using MountCarmelweb.Controllers;
using System.Runtime.Serialization;
using System;
using System.Drawing;

namespace MountCarmelweb
{
    public static class tallyResponse
    {
        public static XElement Response(int code, string message, int errcode)
        {
            return new XElement("ENVELOPE",
                    new XElement("HEADER",
                        new XElement("VERSION", "1"),
                        new XElement("STATUS", code)
                        ),
                        new XElement("BODY",
                        new XElement("DATA",
                        //new XElement("STATUS.LIST",
                        new XElement("STATUS",
                        new XElement("CODE", errcode),
                        new XElement("DESC", message))))

                     );
        }
        public static XElement OwnObjectResponse(int code, string message)
        {
            return new XElement("ERROR",
                    new XElement("Code", code),
                    new XElement("Desc", message)
                    );
        }
    }
    [XmlRoot("DATABASE")]
    public class DataBase
    {
        public static readonly XmlSerializerNamespaces ns =
            new XmlSerializerNamespaces(new[] { new System.Xml.XmlQualifiedName("", "") });
        public int id { get; set; }

        [XmlElement("NAME")]
        public string Name { get; set; }

        [XmlElement("DOSNAME")]
        public string DosName { get; set; }

        public DataBase()
        {
        }
        public DataBase(string name, string dosName)
        {
            Name = name;
            DosName = dosName;

        }

        public static DataBase FromXML(string xml)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(DataBase));
            using (TextReader reader = new StringReader(xml))
            {
                return (DataBase)serializer.Deserialize(reader);
            }
        }

        public static string CreateDataBase(XmlDocument xmldataBase)
        {
            DataBase dataBase = FromXML(xmldataBase.DocumentElement.OuterXml);
            if (!string.IsNullOrEmpty(dataBase.Name))
            {
                string nextdbname = DosNameOfNextDataBase();
                System.IO.Directory.CreateDirectory(Program.apppath + @"\" + nextdbname);

                using (var db = new LiteDatabase(Program.apppath + @"\"+ nextdbname + @"\SIPL.tdd"))
                {
                    var col = db.GetCollection<DataBase>("dbinfocoll");
                    col.Insert(dataBase);

                }
            }
            var response = new XElement("ENVELOPE",
                new XElement("HEADER",
                    new XElement("VERSION", "1"),
                    new XElement("STATUS", "1")
                    ),
                    new XElement("BODY",
                    new XElement("DATA",
                    new XElement("STATUS.LIST",
                    new XElement("STATUS",
                    new XElement("CODE", string.IsNullOrEmpty(dataBase.Name) ? "1" : "0"),
                    new XElement("DESC", string.IsNullOrEmpty(dataBase.Name) ? "DB Name Empty Not Allowed" : "Ok")))))

                 );

            return response.ToString();
        }
        private static string DosNameOfNextDataBase()
        {
            //string curPath = System.AppDomain.CurrentDomain.BaseDirectory + @"\Data\";




            var directories = Directory.GetDirectories(Program.apppath);

            List<string> existingdirs = new List<string>();
            foreach (var dir in directories)
            {
                existingdirs.Add(new DirectoryInfo(dir).Name);
            }
            //string[] folders = System.IO.Directory.GetDirectories(curPath, "*", System.IO.SearchOption.AllDirectories);




            IEnumerable<string> repeatwithString = Enumerable.Range(1, 100).Select(i => { return i.ToString("000"); }).ToList();
            //string firstdb = repeatwithString.Except(existingdirs).First();
            //repeatwithString.ToList().ForEach(Console.WriteLine);
            //existingdirs.ToList().ForEach(Console.WriteLine);
            //Console.WriteLine(firstdb + " path=" + curPath);
            //Console.ReadLine();
            //System.IO.Directory.CreateDirectory("Data");
            //System.IO.Directory.CreateDirectory(@"Data\" + repeatwithString.Except(existingdirs).First());
            return repeatwithString.Except(existingdirs).First();
        }

        public static string DataBasetoXML()
        {
            //string curPath = System.AppDomain.CurrentDomain.BaseDirectory;
            //string curPath = datapath + @"\";



            var directories = Directory.GetDirectories(Program.apppath);

            List<DataBase> existingdatabases = new List<DataBase>();

            foreach (var dir in directories)
            {
                using (var db = new LiteDatabase(dir + @"\SIPL.tdd"))
                {
                    var col = db.GetCollection<DataBase>("dbinfocoll");

                    existingdatabases.Add(new DataBase(col.FindAll().First().Name, new DirectoryInfo(dir).Name));
                }
            }

            var xs = new XmlSerializer(typeof(List<DataBase>));
            var sw = new StringWriter();
            xs.Serialize(sw, existingdatabases, ns);
            return sw.ToString();
        }
        public static bool IsDataBaseExists(string db)
        {
            var directories = Directory.GetDirectories(Program.apppath);

            List<string> existingdirs = new List<string>();
            foreach (var dir in directories)
            {
                existingdirs.Add(new DirectoryInfo(dir).Name);
            }
            //string[] folders = System.IO.Directory.GetDirectories(curPath, "*", System.IO.SearchOption.AllDirectories);




            IEnumerable<string> repeatwithString = Enumerable.Range(1, 100).Select(i => { return i.ToString("000"); }).ToList();

            return repeatwithString.Contains(db);
        }
        public static List<DataBase> dblist()       //this method not yet used
        {
            //string curPath = System.AppDomain.CurrentDomain.BaseDirectory;
            //DirectoryInfo di = new DirectoryInfo(curPath);


            var directories = Directory.GetDirectories(Program.apppath);

            List<DataBase> existingdatabases = new List<DataBase>();

            foreach (var dir in directories)
            {
                using (var db = new LiteDatabase(dir + @"\SIPL.tdd"))
                {
                    var col = db.GetCollection<DataBase>("dbinfocoll");

                    existingdatabases.Add(new DataBase(col.FindAll().First().Name, new DirectoryInfo(dir).Name));
                }
            }
            return existingdatabases;
        }
        public static async Task<Object> SaveAllBulkObjAsync(InvData pinvData, string pdosname)
        {
            return await Task.Run(() =>
            {
                using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
                {


                    db.DropCollection("invoices");
                    db.DropCollection("persons");
                    db.DropCollection("items");
                    db.DropCollection("locations");


                    db.GetCollection<Invoice>("invoices").Upsert(pinvData.invoices);
                    db.GetCollection<Person>("persons").Upsert(pinvData.persons);
                    db.GetCollection<Item>("items").Upsert(pinvData.items);
                    db.GetCollection<Location>("locations").Upsert(pinvData.locations);

                    //Console.WriteLine(JsonConvert.SerializeObject(pinvData));
                    return "deleted and udated";
                }


            });
        }
        public static async Task<int> SaveTransferVchsAsync(List<Invoice> pinvData, string pdosname)
        {
            return await Task.Run(() =>
            {
                using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
                {
                    db.GetCollection<Invoice>("invoices").Upsert(pinvData);
                    return pinvData.Count;
                }
            });
        }
        public static async Task<List<NameHolder>> CompanywisePurchasees( long fromdate, long todate)
        {
            return await Task.Run(() =>
            {
                List<NameHolder> nameHolders = new List<NameHolder>();
                var directories = Directory.GetDirectories(Program.apppath);


                var nameHolderComparer = new NameHolderComparer();

                foreach (var dir in directories)
                {
                    using (var db = new LiteDatabase(dir + @"\SIPL.tdd"))
                    {
                        var cmpname = db.GetCollection<DataBase>("dbinfocoll").FindById(1)?.Name; // Assuming Id 1 is correct
                        var uomDict = db.GetCollection<Item>("items")
                                        .FindAll()
                                        .ToDictionary(item => item.id, item => item.uom);
                        var col = db.GetCollection<Invoice>("invoices")
                                    .FindAll()
                                    .Where(d => string.Equals(d.vchname, "purchase", StringComparison.OrdinalIgnoreCase) && d.date >= fromdate && d.date <= todate)
                                    .SelectMany(a => a.invoiceitems
                                        .Select(p => new ADatewiseinvoice
                                        {
                                            date = a.edate,
                                            qitemid = p.itemid,
                                            itemname = p.itemname ?? "Unknown",
                                            locationid = p.locationid,
                                            locationname = p.locationname,
                                            
                                            qty = p.qty,
                                            rate = p.rate,
                                            amt = p.amount,
                                            PartyName = a.partyname,
                                            UniqID = a.unique1,
                                            VchName = a.vchname,
                                            //cmpname = db.GetCollection<DataBase>("dbinfocoll").FindById(1).Name,
                                            //UOM= db.GetCollection<Item>("items").FindById(p.itemid).uom
                                            //cmpno = dir
                                            cmpname = cmpname, // Use pre-fetched cmpname
                                            UOM = uomDict.ContainsKey(p.itemid) ? uomDict[p.itemid] : null // Use pre-fetched UOM from dictionary

                                        }))
                                    .GroupBy(i => i.itemname.ToLower())
                                    .Select(g => new NameHolder
                                    {
                                        name = g.Key,
                                        aDatewiseinvoices = g.ToList()
                                        //aDatewiseinvoices = g.OrderBy(x => x.rate).ToList() // Sort by rate
                                    })
                                    .ToList();

                        foreach (var item in col)
                        {
                            var existing = nameHolders.FirstOrDefault(n => nameHolderComparer.Equals(n, item));
                            if (existing == null)
                            {
                                nameHolders.Add(item);
                            }
                            else
                            {
                                existing.aDatewiseinvoices.AddRange(item.aDatewiseinvoices);
                            }
                        }

                        // Add new entries to nameHolders
                        //nameHolders.AddRange(col);

                    }
                    
                }
                //nameHolders = nameHolders.Distinct(nameHolderComparer).ToList();

                //JsonConvert.SerializeObject(nameHolders, Newtonsoft.Json.Formatting.Indented);
                return nameHolders;

            });
        }
        public static async Task<List<flattenentry>> Companywiseclosingstock(long fromdate, long todate)
        {
            return await Task.Run(() =>
            {
                List<flattenentry> compclosing = new List<flattenentry>();
                var directories = Directory.GetDirectories(Program.apppath);
                    foreach (var dir in directories)
                    {
                        using (var db = new LiteDatabase(dir + @"\SIPL.tdd"))
                        {
                        var locations = db.GetCollection<Location>("locations")
                                            .FindAll()
                                            .ToDictionary(loc => loc.id, loc => loc.Specification);

                        var items = db.GetCollection<Item>("items")
                                      .FindAll()
                                      .ToDictionary(item => item.id, item => item.uom);
                        var allinvoices = db.GetCollection<Invoice>("invoices")
                                                       .FindAll().Where(invoice => invoice != null && invoice.date >= fromdate && invoice.date <= todate)
                                                       .SelectMany(invoice => invoice.invoiceitems
                                                       .Select(item =>
                                                        new flattenentry
                                                        {
                                                            cmpname = db.GetCollection<DataBase>("dbinfocoll").FindById(1).Name,
                                                            itemid = item.itemid,
                                                            locationid = item.locationid,
                                                            inqty = item.qty,
                                                            outqty = 0,
                                                            itemname = item.itemname,
                                                            locationname = item.locationname

                                                        }));
                            var computeOUT = db.GetCollection<Invoice>("invoices")
                                                        .FindAll().Where(invoice => invoice != null && invoice.date >= fromdate && invoice.date <= todate)
                                                        .Where(f => f.slocationid != 0)
                                                        .SelectMany(a => a.invoiceitems
                                                            .Where(item => item.itemid != 0)
                                                            .Select(p => new flattenentry
                                                            {
                                                                cmpname= db.GetCollection<DataBase>("dbinfocoll").FindById(1).Name,
                                                                itemid = p.itemid,
                                                                itemname = p.itemname,
                                                                locationid = a.slocationid,
                                                                locationname = a.slocationstr,
                                                                inqty = 0,
                                                                outqty = p.qty,
                                                            })
                                                        );
                            
                            var mergedInvoices = allinvoices
                                                    .Concat(computeOUT)
                                                    .GroupBy(invoice => new { invoice.itemid, invoice.locationid, invoice.cmpname })
                                                    .Select(group => new flattenentry
                                                    {
                                                        cmpname = group.Key.cmpname,
                                                        itemid = group.Key.itemid,
                                                        locationid = group.Key.locationid,
                                                        itemname = group.First().itemname,
                                                        locationname = group.First().locationname,
                                                        inqty = group.Sum(invoice => invoice.inqty),
                                                        outqty = group.Sum(invoice => invoice.outqty),
                                                        locspec = locations.TryGetValue(group.Key.locationid, out var spec) ? spec : "Unknown",
                                                        uom = items.TryGetValue(group.Key.itemid, out var uom) ? uom : "Unknown"
                                                    });
                        
                            compclosing.AddRange(mergedInvoices);


                        }

                    
                    }
                return compclosing;
                    
                
            });
        }

    }

    public class NameHolder
    {
        public string name { get; set; }
        public List<ADatewiseinvoice> aDatewiseinvoices { get; set; }

    }
    public class NameHolderComparer : IEqualityComparer<NameHolder>
    {
        public bool Equals(NameHolder x, NameHolder y)
        {
            return x.name == y.name;
        }
        public int GetHashCode(NameHolder obj)
        {
            return obj.name.GetHashCode();
        }
    }
    public class CompanywiseItem
    {
        public string name { get; set; }
        public List<flattenentry> aDatewiseinvoices { get; set; }
    }
    public class CompanywiseItemComparer : IEqualityComparer<CompanywiseItem>
    {
        public bool Equals(CompanywiseItem x, CompanywiseItem y)
        {
            return x.name == y.name;
        }
        public int GetHashCode(CompanywiseItem obj)
        {
            return obj.name.GetHashCode();
        }
    }

    [XmlRoot(ElementName = "ITEM")]
    public class Item
    {
        private static readonly XmlSerializerNamespaces ns =
                new XmlSerializerNamespaces(new[] { new System.Xml.XmlQualifiedName("", "") });
        //private readonly static string MyDBPath = "Data\\";

        [XmlElement("ID")]
        public int id { get; set; }

        [XmlElement("NAME")]
        public string name { get; set; }

        [XmlElement("UOM")]
        public string uom { get; set; }

        [XmlElement("GROUPNAME")]
        public string groupname { get; set; }

        [XmlElement("CATEGORY")]
        public string Category { get; set; }

        [XmlElement("RATE")]
        public double Rate { get; set; }

        [XmlElement("CLOSINGQTY")]
        public double ClosingQty { get; set; }

        [XmlElement("PREFIX")]
        public string prefix { get; set; }

        [XmlElement("SUFFIX")]
        public string suffix { get; set; }

        [XmlArray("MASTERBRANDS.LIST")]
        [XmlArrayItem("MASTERBRANDS")]
        public string[] mastermrandslist { get; set; } //= new List<MASTERBRAND>();

        [XmlArray("MASTERCAPACITY.LIST")]
        [XmlArrayItem("MASTERCAPACITY")]
        public string[] mastercapacitylist { get; set; }

        [XmlElement("ISDELETED")]
        public bool isdeleted { get; set; }

        public Item()
        {
        }
        public Item(string name)
        {
            this.name = name;
        }

        public Item(int id, string name)
        {
            this.id = id;
            this.name = name;
        }
        public Item(int pid, string pname, double closqty)
        {
            id = pid; name = pname; ClosingQty = closqty;
        }
        public static Item FromXML(string xml)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(Item));
            using (TextReader reader = new StringReader(xml))
            {
                return (Item)serializer.Deserialize(reader);
            }
        }

        //public Item(int pid, string pname,string puom,string pgrp)
        public Item(string pname, string puom, string pgrp, string cat)
        {
            //this.id = pid;
            name = pname;
            uom = puom;
            groupname = pgrp;
            Category = cat;
        }
        public static Item GetItem(string pdosname, int pid)
        {
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                return db.GetCollection<Item>("items").FindById(pid);
            }

        }
        public static async Task<int> SingleSave(string pdosname, Item pitem)
        {
            return await Task.Run(() =>
            {


                using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
                {
                    var list = db.GetCollection<Item>("items");
                    var uitems = list.FindOne(d => d.name.ToLower().Equals(pitem.name.ToLower()));
                    if (uitems != null)
                    {

                        return 1;
                    }
                    else
                    {
                        list.Upsert(pitem);
                        return 0;
                    }


                }
            });
        }
        public static async Task<int> BulkSave(string pdosname, List<Item> pitems)
        {
            return await Task.Run(() =>
            {


                using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
                {
                    var items = db.GetCollection<Item>("items");
                    items.InsertBulk(pitems);
                    return pitems.Count;
                }
            });

        }
        public static async Task<string> SaveItem(string pdosname, Item item)
        {
            return await Task.Run(() =>
            {


                using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
                {
                    if (!string.IsNullOrEmpty(item.prefix))
                    {


                        var d = db.GetCollection<Item>("items").FindOne(a => a.prefix.Equals(item.prefix));
                        if (d != null && d.id != item.id)
                        {
                             return tallyResponse.Response(0, "prefix or suffix0 is duplicate", 120).ToString();
                            //return tallyResponse.OwnObjectResponse(0, "prefix or suffix0 is duplicate").ToString();
                        }
                    }


                    var items = db.GetCollection<Item>("items");
                    var latest = items.FindOne(Query.All(-1));

                    int newid = (latest != null) ? latest.id + 1 : 1;

                    if (item != null && item.id == -1)
                    {

                        item.id = newid;
                        //items.Insert(item);
                    }

                    bool upsertResult = items.Upsert(item);

                    if (upsertResult)
                    {
                        // Upsert operation was successful
                        return tallyResponse.Response(1, "successful inserted", newid).ToString();
                    }
                    else
                    {
                        // Upsert operation replaced an existing document
                        Console.WriteLine("Upsert operation replaced an existing document.");
                        return tallyResponse.Response(1, "successful updated", newid).ToString();
                    }


                }

            });
        }

        public static string ItemtoXML(string pdosname)
        {
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                var items = db.GetCollection<Item>("items").FindAll();
                IList<Item> allcustomers = items.Where(a => !a.isdeleted).ToList();
                //return Ok<IList<Order>>(allorder);
                var xs = new XmlSerializer(typeof(List<Item>));
                var sw = new StringWriter();
                xs.Serialize(sw, allcustomers, ns);
                return sw.ToString();
            }
        }
        public static List<Item> GetAllItems(string pdosname)
        {
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                var items = db.GetCollection<Item>("items").FindAll();
                return items.ToList();
            }

        }

        public static List<Item> GetFAItems(string pdosname)
        {
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                var items = db.GetCollection<Item>("items").Find(o => o.Category.Contains("Fixed Assets"));
                return items.ToList();
            }

        }

        public static bool IsDuplicateItem(string pname)
        {
            using (var db = new LiteDatabase(@"Filename=Data\" + pname + @"\SIPL.tdd;connection=shared;"))
            {
                var mitems = db.GetCollection<Item>("items");

                Dictionary<string, Item> itemwise = mitems.FindAll().ToDictionary(x => x.name, x => x);
                return itemwise.ContainsKey(pname);

            }
        }

        public static async Task<string> DeleteItemAsync(int ptid, string pname)
        {
            return await Task.Run(() =>
            {
                using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pname + @"\SIPL.tdd;connection=shared;"))
                {
                    var invos = db.GetCollection<Item>("items");
                    if (Invoice.SelectedItemsTransactions(pname, ptid).Count == 0)
                    {
                        Item di = new Item { id = ptid, isdeleted = true };
                        invos.Upsert(di);
                        return new XElement("status", "Deleted Successfully").ToString();
                    }
                    else
                    {
                        return new XElement("status", "Some Transactions might be in DB").ToString();
                    }




                }
            });
        }


    }

    [XmlRoot("LOCATION")]
    public class Location
    {
        [XmlElement("ID")]
        public int id { get; set; }

        [XmlElement("NAME")]
        public string name { get; set; }

        [XmlElement("SPECIFICATION")]
        public string Specification { get; set; }

        [XmlElement("ISDELETED")]
        public bool isdeleted { get; set; }
        public Location() { }

        public static Location FromXML(string xml)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(Location));
            using (TextReader reader = new StringReader(xml))
            {
                return (Location)serializer.Deserialize(reader);
            }
        }

        public static string SaveLocation(string pdosname, Location loc)
        {
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                var locs = db.GetCollection<Location>("locations");
                int newid = locs.Count() + 1;
                if (loc.id.Equals(-1))
                {

                    loc.id = newid;
                    //items.Insert(item);
                }



                locs.Upsert(loc);
                var response = new XElement("ENVELOPE",
                        new XElement("HEADER",
                            new XElement("VERSION", "1"),
                            new XElement("STATUS", "1")
                            ),
                            new XElement("BODY",
                            new XElement("DATA",
                            new XElement("STATUS.LIST",
                            new XElement("STATUS",
                            new XElement("CODE", loc.id),
                            new XElement("DESC", "Ok")))))

                         );

                return response.ToString();
            }
        }
        public static Location GetLocation(int pid, string pdosname)
        {
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                return db.GetCollection<Location>("locations").FindById(pid);
            }
        }
        public static string LocationtoXML(string pdosname)
        {
            //using (var db = new LiteDatabase(@"\Data\" + pdosname + "\\SIPL.tdd"))
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                var locs = db.GetCollection<Location>("locations").FindAll();
                IList<Location> alllocations = locs.Where(a => !a.isdeleted).ToList();
                //return Ok<IList<Order>>(allorder);
                var xs = new XmlSerializer(typeof(List<Location>));
                var sw = new StringWriter();
                xs.Serialize(sw, alllocations, DataBase.ns);
                return sw.ToString();
            }
        }
        public static List<Location> GetLocations(string pdosname)
        {
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                var locs = db.GetCollection<Location>("locations");
                List<Location> alllocations = locs.FindAll().ToList();
                return alllocations;
            }
        }

        public Location(string name, string specification)
        {

            this.name = name;
            Specification = specification;
        }
        public static async Task<string> CreateLocationAsync(Location pLoc, string pdosname)
        {
            return await Task.Run(() =>
            {


                using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
                {

                    var locs = db.GetCollection<Location>("locations");

                    int newid = locs.Count() + 1;

                    if (locs.FindOne(a => a.name == pLoc.name) == null)
                    {

                        pLoc.id = newid;

                        locs.Upsert(pLoc);
                        return pLoc.id.ToString() + $" Created in {pdosname} ";
                    }
                    else
                    {
                        return pLoc.id.ToString() + " Already Exists";
                    }




                }
            });
        }
        public static async Task<string> DeleteLocationAsync(int ptid, string pname)
        {
            return await Task.Run(() =>
            {
                using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pname + @"\SIPL.tdd;connection=shared;"))
                {
                    var locations = db.GetCollection<Location>("locations");
                    if (Invoice.SelectedGodownInOutAsync(pname, ptid).Result.Count == 0)
                    {
                        Location di = new Location { id = ptid, isdeleted = true };
                        locations.Upsert(di);
                        return new XElement("status", "Deleted Successfully").ToString();
                    }
                    else
                    {
                        return new XElement("status", "Some Transactions might be in DB").ToString();
                    }




                }
            });
        }

    }

    [XmlRoot("INVOICE")]
    public class Invoice
    {

        [XmlElement("ID")]
        public int id { get; set; }

        [XmlElement("DATE")]
        public long date { get; set; }


        [XmlElement("EDATE")]
        public string edate { get; set; }


        [XmlElement("PARTYNAME")]
        public string partyname { get; set; }


        [XmlElement("PARTYID")]
        public int partyid { get; set; }


        [XmlElement("PARTYINVNO")]
        public string partyinvno { get; set; }


        [XmlElement("PARTYINVDATE")]
        public string partyinvdate { get; set; }


        [XmlElement("UNIQUEONE")]
        public string unique1 { get; set; }


        [XmlElement("VCHNAME")]
        public string vchname { get; set; }

        //[JsonIgnore]
        [XmlElement("SLOCATIONSTR")]
        public string slocationstr { get; set; }

        //[JsonIgnore]
        [XmlElement("SLOCATIONID")]
        public int slocationid { get; set; }


        [XmlElement("NARRATION")]
        public string narration { get; set; }


        [XmlElement("INVOICEITEM.LIST")]
        public List<InvoiceItem> invoiceitems { get; set; }    // = new List<InvoiceItem>();
        public Invoice() { }

        public Invoice(int id, long date, string edate, string unique1, string vchname, string slocationstr, int slocationid, string narration, List<InvoiceItem> invoiceitems)
        {
            this.id = id;
            this.date = date;
            this.edate = edate;
            this.unique1 = unique1;
            this.vchname = vchname;
            this.slocationstr = slocationstr;
            this.slocationid = slocationid;
            this.narration = narration;
            this.invoiceitems = invoiceitems;
        }
        public Invoice(int id, long date, string edate, string unique1, string vchname, string narration, List<InvoiceItem> invoiceitems)
        {
            this.id = id;
            this.date = date;
            this.edate = edate;
            this.unique1 = unique1;
            this.vchname = vchname;

            this.narration = narration;
            this.invoiceitems = invoiceitems;
        }

        /* public Invoice(int id, string edate, string partyname, int partyid, string partyinvno, string partyinvdate, string unique1, string vchname, string narration, List<InvoiceItem> invoiceitems)
         {
             this.id = id;
             this.edate = edate;
             this.partyname = partyname;
             this.partyid = partyid;
             this.partyinvno = partyinvno;
             this.partyinvdate = partyinvdate;
             this.unique1 = unique1;
             this.vchname = vchname;
             this.narration = narration;
             this.invoiceitems = invoiceitems;
         }*/

        /*public Invoice(string eDate, string partyName, int partid, string partyInvNo, string partyInvDate, string unique1, string narration)
        {
            
            this.edate = eDate;
            this.partyname = partyName;
            this.partyid = partid;
            this.partyinvno = partyInvNo;
            this.partyinvdate = partyInvDate;
            this.unique1 = unique1;
            this.narration = narration;
            vchname = "Purchase";
            invoiceitems = new List<InvoiceItem>();

            DateTime date;
            
            if( DateTime.TryParse(eDate, out date)) { 
                this.Date = long.Parse(date.ToString("yyyyMMdd"));
            }
            
            
        }*/


        public static string AddMultipleInvoice(string pdosname, Dictionary<string, Invoice> invoices)
        {
            List<Invoice> invoiceList = new List<Invoice>();
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {

                int newid = db.GetCollection<Invoice>("invoices").Count() + 1;
                foreach (var kvp in invoices)
                {
                    Invoice invoice = kvp.Value;

                    // Modify the ID here, for example, by appending "_modified"
                    invoice.id = newid;

                    // Add the modified Invoice to the List
                    invoiceList.Add(invoice);
                    newid++;
                }
                db.GetCollection<Invoice>("invoices").InsertBulk(invoiceList);
                return $"{invoiceList.Count} updated";
            }
        }
        public void AddInvoiceItem(InvoiceItem pinvoiceItems)
        {
            invoiceitems.Add(pinvoiceItems);
        }
        public static Invoice FromXML(string xml)
        {

            XmlSerializer serializer = new XmlSerializer(typeof(Invoice));
            using (TextReader reader = new StringReader(xml))
            {
                return (Invoice)serializer.Deserialize(reader);
            }
        }
        public static string SaveInvoice(string pdosname, Invoice inv)
        {
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                var invos = db.GetCollection<Invoice>("invoices");
                DateTime parsedDate = DateTime.ParseExact(inv.edate, "dd-MM-yyyy", null);
                string formattedDate = parsedDate.ToString("yyyyMMdd");
                inv.date = long.Parse(formattedDate);
                var latest = invos.FindOne(Query.All(-1));

                int newid = (latest != null) ? latest.id + 1 : 1;


                if (inv != null && inv.id == -1)
                {

                    inv.id = newid;
                    //items.Insert(item);
                    
                }
                else
                {
                    Invoice inv1 = db.GetCollection<Invoice>("invoices").FindById(inv.id);
                    
                }
                var result = invos.Upsert(inv);





                invos.Upsert(inv);
                var response = new XElement("ENVELOPE",
                        new XElement("HEADER",
                            new XElement("VERSION", "1"),
                            new XElement("STATUS", "1")
                            ),
                            new XElement("BODY",
                            new XElement("DATA",
                            new XElement("STATUS.LIST",
                            new XElement("STATUS",
                            new XElement("CODE", inv.id),
                            new XElement("DESC", "Ok")))))

                         );

                return response.ToString();
            }

        }
        public static string DeleteTransaction(string pdosname, int ptid)
        {
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                var invos = db.GetCollection<Invoice>("invoices");
                Invoice di = new Invoice { id = ptid };
                Console.WriteLine(di);
                //di.id = ptid;
                //bool operation = invos.Delete(ptid);
                invos.Upsert(di);

                return new XElement("status", "Deleted Successfully").ToString();

                //return invos.Delete(ptid).ToString();
            }
        }
        public static string InvoicetoXML(string pdosname, string format, long fromdate, long todate)
        {
            //using (var db = new LiteDatabase(@"\Data\" + pdosname + "\\SIPL.tdd"))
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                var invos = db.GetCollection<Invoice>("invoices");
                IList<Invoice> allinvoices = invos.FindAll().Where(g => g.date >= fromdate && g.date <= todate).OrderBy(h => h.date).ToList();
                //return Ok<IList<Order>>(allorder);

                if (format.Equals("xml"))
                {

                    var xs = new XmlSerializer(typeof(List<Invoice>));
                    var sw = new StringWriter();
                    xs.Serialize(sw, allinvoices, DataBase.ns);
                    return sw.ToString();
                }
                else
                {
                    Dictionary<string, IList<Invoice>> dict = new Dictionary<string, IList<Invoice>>();
                    dict.Add("allinvoices", allinvoices);
                    return JsonConvert.SerializeObject(dict);
                }
            }
        }
        public static List<Invoice> GetExistingTransferVchs(string pdosname)
        {
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                var invs = db.GetCollection<Invoice>("invoices").FindAll().Where(d => d.vchname.ToLower() == "transfer");
                return invs.ToList();
            }
        }
        public static List<Invoice> GetExistingbothInvoicesList(string pdosname)
        {
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                var invs = db.GetCollection<Invoice>("invoices").FindAll();
                return invs.ToList();
            }
        }
        public static string SelecteditemInvoicetoXML(string pdosname, int pitemid, string format, long fromdate, long todate)
        {
            //using (var db = new LiteDatabase(@"\Data\" + pdosname + "\\SIPL.tdd"))
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                var invos = db.GetCollection<Invoice>("invoices");
                IList<Invoice> allinvoices = invos.FindAll().Where(s => s.invoiceitems.Any(a => a.itemid.Equals(pitemid)) &&  s.date >= fromdate && s.date <= todate).ToList();
                //return Ok<IList<Order>>(allorder);

                if (format.Equals("xml"))
                {

                    var xs = new XmlSerializer(typeof(List<Invoice>));
                    var sw = new StringWriter();
                    xs.Serialize(sw, allinvoices, DataBase.ns);
                    return sw.ToString();
                }
                else
                {
                    Dictionary<string, IList<Invoice>> dict = new Dictionary<string, IList<Invoice>>();
                    dict.Add("allinvoices", allinvoices);
                    return JsonConvert.SerializeObject(dict);
                }
            }
        }

        public static List<Invoice> SelectedItemsTransactions(string pdosname, int pitemid)
        {
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                var invos = db.GetCollection<Invoice>("invoices");
                List<Invoice> allinvoices = invos.FindAll().Where(s => s.invoiceitems.Any(a => a.itemid.Equals(pitemid))).ToList();
                return allinvoices;
            }
        }
        public static string ItemsWithClosingBalancetoXML(string pdosname)
        {
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                var computItemMasters = db.GetCollection<Item>("items").FindAll().ToList();
                var computLocationMasters = db.GetCollection<Location>("locations").FindAll().ToList();

                var computeIN = db.GetCollection<Invoice>("invoices")
                    .FindAll()
                    .Where(invoice => invoice != null)
                    .SelectMany(invoice => invoice.invoiceitems.Where(item => item != null).Select(item =>
                        new aInvoice
                        {
                            itemid = item.itemid,
                            locationid = item.locationid,
                            inqty = item.qty,
                            outqty = 0,
                            itemname = item.itemname,
                            locationname = item.locationname

                        }
                    ));


                var computeOUT = db.GetCollection<Invoice>("invoices")
                    .FindAll()
                    .Where(f => f.slocationid != 0)
                    .SelectMany(a => a.invoiceitems
                        .Where(item => item.itemid != 0)
                        .Select(p => new aInvoice
                        {
                            itemid = p.itemid,
                            itemname = p.itemname,
                            locationid = a.slocationid,
                            locationname = a.slocationstr,
                            inqty = 0,
                            outqty = p.qty,
                        })
                    );



                var listin = computeIN.GroupBy(a => new { a.itemid, a.locationid })
                    .Select(a =>
                    new aInvoice
                    {
                        itemid = a.First().itemid,
                        itemname = a.First().itemname,
                        inqty = a.Sum(c => c.inqty),
                        outqty = a.Sum(c => c.outqty),
                        locationid = a.First().locationid,
                        locationname = a.First().locationname,
                        //locationspec = computLocationMasters.First(s => s.id.Equals(a.First().locationid)).Specification

                    });

                var listout = computeOUT.GroupBy(a => new { a.itemid, a.locationid })
                    .Select(a =>
                    new aInvoice
                    {
                        itemid = a.First().itemid,
                        itemname = a.First().itemname,
                        inqty = a.Sum(c => c.inqty),
                        outqty = a.Sum(c => c.outqty),

                        locationid = a.First().locationid,
                        locationname = a.First().locationname,
                        //locationspec = computLocationMasters.First(s => s.id.Equals(a.First().locationid)).Specification


                    });
                //Console.WriteLine( MS.ToString() );
                try
                {
                    var both = listin.Select(x =>
                        new aInvoice
                        {
                            itemid = x.itemid,
                            itemname = GetNameById(computItemMasters, x.itemid),
                            locationid = x.locationid,
                            locationname = GetLocNameById(computLocationMasters, x.locationid),
                            locationspec = GetSpecificationById(computLocationMasters, x.locationid),
                            inqty = x.inqty,
                            outqty = x.outqty
                        }
                    ).Union(listout.Select(b =>
                        new aInvoice
                        {
                            itemid = b.itemid,
                            itemname = computItemMasters.FirstOrDefault(s => b.itemid.Equals(s.id)).name,
                            locationid = b.locationid,
                            locationname = computLocationMasters.FirstOrDefault(s => b.locationid.Equals(s.id)).name,
                            locationspec = computLocationMasters.FirstOrDefault(s => b.locationid.Equals(s.id)).Specification,
                            inqty = b.inqty,
                            outqty = b.outqty
                        }
                        )).Union(computItemMasters.Select(c =>
                        new aInvoice
                        {
                            itemid = c.id,
                            itemname = c.name

                        }));


                    JObject summ = new JObject();
                    summ["records"] = JToken.FromObject(both);
                    //summ["records2"] = JToken.FromObject(computeOUT);
                    //Console.WriteLine(JsonConvert.SerializeObject(summ));
                    return JsonConvert.SerializeObject(summ);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return null;
                }
            }

        }
        static string GetNameById(List<Item> masters, int id)
        {
            var master = masters.FirstOrDefault(s => id.Equals(s.id));
            if (master == null)
            {
                Console.WriteLine($"Item with id {id} not found.");
            }
            return master?.name ?? "Unknown";
        }

        static string GetLocNameById(List<Location> masters, int id)
        {
            var master = masters.FirstOrDefault(s => id.Equals(s.id));
            if (master == null)
            {
                Console.WriteLine($"Location with id {id} not found.");
            }
            return master?.name ?? "Unknown";
        }

        static string GetSpecificationById(List<Location> masters, int id)
        {
            var master = masters.FirstOrDefault(s => id.Equals(s.id));
            return master?.Specification ?? "Unknown";
        }
        static string GetUOMById(List<Item> masters, int id)
        {
            var master = masters.FirstOrDefault(s => id.Equals(s.id));
            return master?.uom ?? "Unknown";
        }
        public static Dictionary<string, List<aInvoice>> GetInOutJsonObject(string pdosname)
        {

            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                var computItemMasters = Item.GetFAItems(pdosname);
                var computLocationMasters = Location.GetLocations(pdosname);
                try
                {
                    var firstcall = db.GetCollection<Invoice>("invoices").FindAll().Where(invoice => invoice != null);
                    List<aInvoice> computeIN = firstcall
                        .SelectMany(invoice => invoice.invoiceitems
                        .GroupBy(item => new { invoiceId = invoice.slocationid, locationId = item.itemid }))
                        .Select(groupedItem =>
                            new aInvoice
                            {
                                itemid = groupedItem.First().itemid,
                                itemname = groupedItem.First().itemname,
                                locationid = groupedItem.Key.locationId, // Assuming you want the locationId from the grouping key
                                locationname = groupedItem.First().locationname,
                                inqty = groupedItem.Sum(item => item.qty),
                                locationspec = GetSpecificationById(computLocationMasters, groupedItem.Key.locationId),
                                outqty = 0
                            }
                        ).ToList();
                    var computeOut = firstcall
                        .SelectMany(invoice => invoice.invoiceitems.Where(item => item != null)
                        .GroupBy(item => new { invoiceId = item.locationid, locationId = item.itemid }))
                        .Select(groupedItem =>
                            new aInvoice
                            {
                                itemid = groupedItem.First().itemid,
                                itemname = groupedItem.First().itemname,
                                locationid = groupedItem.Key.locationId, // Assuming you want the locationId from the grouping key
                                locationname = groupedItem.First().locationname,
                                inqty = groupedItem.Sum(item => item.qty),
                                locationspec = GetSpecificationById(computLocationMasters, groupedItem.Key.locationId),
                                outqty = 0
                            }
                        ).ToList();

                    Dictionary<string, List<aInvoice>> inout = new Dictionary<string, List<aInvoice>>();
                    inout["in"] = computeIN;
                    inout["out"] = computeOut;
                    //return JsonConvert.SerializeObject(inout);
                    return inout;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"An error occurred: {ex}");
                    return null;
                    // Return a specific error response to the client or throw the exception
                    //return StatusCode(500, "Internal Server Error");

                }
            }

        }
        public static string ItemWiseAllTransactions(long fromdate, long todate, string pdosname)
        {
            var computItemMasters = Item.GetAllItems(pdosname);
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {

                var AllitemstransactionsF = db.GetCollection<Invoice>("invoices").Find(g => g.date >= fromdate || g.date <= todate);
                //.Where(w => w.VchName.ToLower().Equals("Purchase".ToLower()));
                if (AllitemstransactionsF.Count() > 0)
                {


                    var Allitemstransactions1 = db.GetCollection<Invoice>("invoices").Find(g => g.date >= fromdate && g.date <= todate)
                    .SelectMany(a => a.invoiceitems
                    .Select(p =>
                    new ADatewiseinvoice
                    {
                        date = a.edate,
                        qitemid = p.itemid,
                        itemname = p.itemname,
                        locationid = p.locationid,
                        locationname = p.locationname,
                        qty = p.qty,
                        rate = p.rate,
                        amt = p.amount,
                        PartyName = a.partyname,
                        UniqID = a.unique1,
                        VchName = a.vchname,
                        UOM = GetUOMById(computItemMasters,p.itemid)

                    }


                        ));

                    Dictionary<int, List<ADatewiseinvoice>> Allitemstransactions = Allitemstransactions1
                         .GroupBy(l => l.qitemid)
                         .ToDictionary(g => g.Key, g => g.ToList());
                    XElement root = new XElement("root");
                    foreach (KeyValuePair<int, List<ADatewiseinvoice>> pair in Allitemstransactions)
                    {
                        root.Add(new XElement("ITEM",
                            from item in pair.Value
                            select new XElement("INVOICE",
                               new XElement("DATE", item.date),
                               new XElement("ITEMNAME", item.itemname),
                               new XElement("UOM",item.UOM),
                               new XElement("PARTYNAME", item.PartyName),
                               new XElement("REFNO", item.UniqID),
                               new XElement("QTY", item.qty),
                               new XElement("LOCATIONNAME",item.locationname),
                               new XElement("LOCATIONID", item.locationid),
                               new XElement("RATE", item.rate),
                               new XElement("AMT", item.amt)

                    )));
                    }
                    /* cl => new InvoiceItem
                          {
                              ItemName= cl.FirstOrDefault().ItemName,
                              ItemID= cl.FirstOrDefault().ItemID,
                              rate= cl.FirstOrDefault().rate,
                              qty= cl.FirstOrDefault().qty,
                              Amount= cl.FirstOrDefault().Amount,
                              LocationID= cl.FirstOrDefault().LocationID,
                              LocationName= cl.FirstOrDefault().LocationName
                          }).ToList();*/
                    //JObject summ = new JObject();
                    //summ["records"] = JToken.FromObject(Allitemstransactions);
                    //summ["records2"] = JToken.FromObject(computeOUT);
                    return root.ToString();
                }
                else
                {
                    //JObject summ = new JObject();
                    return new XElement("root").ToString();
                }


            }


        }
        public static string SelectedGodownInOut(string pdosname, int plocid, long fromdate, long todate)
        {

            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                ////////////////
                var computeIN_a = db.GetCollection<Invoice>("invoices").FindAll().Where(g => g.date >= fromdate && g.date <= todate)
                            .SelectMany(a => a.invoiceitems.Where(y => y.locationid.Equals(plocid))
                            .Select(p => new flattenentry

                            {
                                itemid = p.itemid,
                                itemname = p.itemname,
                                locationid = p.locationid,
                                locationname = p.locationname,
                                inqty = p.qty,
                                outqty = 0

                            }

                            ));


                var computeOUT = db.GetCollection<Invoice>("invoices").FindAll().Where(g => g.date >= fromdate && g.date <= todate)
                        .Where(f => f.slocationid.Equals(plocid))
                        .SelectMany(a => a.invoiceitems.Select(x =>
                        new flattenentry
                        {
                            itemid = x.itemid,
                            itemname = x.itemname,
                            locationid = a.slocationid,
                            locationname = a.slocationstr,
                            inqty = 0,
                            outqty = x.qty,

                        }
                        )).ToList();
                List<flattenentry> summarized = computeIN_a.Concat(computeOUT).ToList();
                JObject summ = new JObject();
                summ["records"] = JToken.FromObject(summarized);
                return JsonConvert.SerializeObject(summ);

                ////////////////////
            }

        }
        //this returns List<flattenentry> all in and out items are considerred. 
        //this is for browser report. JS will sumup itemwise in and out
        public static async Task<List<flattenentry>> SelectedGodownInOutAsync(string pdosname, int plocid)
        {
            return await Task.Run(() =>
            {


                using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
                {
                    ////////////////
                    var computeIN = db.GetCollection<Invoice>("invoices").FindAll()
                                .SelectMany(a => a.invoiceitems.Where(y => y.locationid.Equals(plocid))
                                .Select(p => new flattenentry

                                {
                                    itemid = p.itemid,
                                    itemname = p.itemname,
                                    locationid = p.locationid,
                                    locationname = p.locationname,
                                    inqty = p.qty,
                                    outqty = 0

                                }

                                ));


                    var computeOUT = db.GetCollection<Invoice>("invoices").FindAll()
                            .Where(f => f.slocationid.Equals(plocid))
                            .SelectMany(a => a.invoiceitems.Select(x =>
                            new flattenentry
                            {
                                itemid = x.itemid,
                                itemname = x.itemname,
                                locationid = a.slocationid,
                                locationname = a.slocationstr,
                                inqty = 0,
                                outqty = x.qty,

                            }
                            )).ToList();
                    List<flattenentry> summarized = computeIN.Concat(computeOUT).ToList();
                    return summarized;

                }
            });
        }
        public static string AllItemsWithSGInOut(string pdosname, int plocid)
        {
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {

                List<Item> masterlist1 = Item.GetAllItems(pdosname);

                var computeIN1 = db.GetCollection<Invoice>("invoices").FindAll().SelectMany(a => a.invoiceitems.Where(y => y.locationid.Equals(plocid)));
                List<flattenentry> computeIN = computeIN1.GroupBy(x => x.itemid)
                                                .Select(p => new flattenentry
                                                {
                                                    itemid = p.Key,
                                                    inqty = p.Sum(x => x.qty),
                                                    outqty = 0
                                                })
                                                .ToList();


                var computeOUT1 = db.GetCollection<Invoice>("invoices").FindAll()
                                     .Where(f => f.slocationid.Equals(plocid))
                                     .SelectMany(a => a.invoiceitems);


                List<flattenentry> computeOUT = computeOUT1.GroupBy(x => x.itemid)
                                .Select(p => new flattenentry
                                {
                                    itemid = p.Key,
                                    inqty = 0,
                                    outqty = p.Sum(x => x.qty)
                                })
                                .ToList();

                foreach (Item g in masterlist1)
                {
                    g.ClosingQty = (computeIN.FirstOrDefault(entry => entry.itemid == g.id)?.inqty ?? 0) - (computeOUT.FirstOrDefault(entry => entry.itemid == g.id)?.outqty ?? 0);
                }


                //var resultList = combinedList.ToList();
                JObject summ = new JObject();
                summ["records"] = JToken.FromObject(masterlist1);
                return JsonConvert.SerializeObject(summ);


            }

        }
        public static async Task<string> SelectedPartyTransactionsAsync(string pdosname, int partyid, long fromdate, long todate)
        {
            return await Task.Run(() =>
            {


                using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
                {
                    var partyTransactions = db.GetCollection<Invoice>("invoices")
                                              .Find(inv => inv.partyid == partyid && inv.date >= fromdate && inv.date <= todate)
                                              .ToList();

                    List<Invoice> partytranscations1 = partyTransactions;
                    var xs = new XmlSerializer(typeof(List<Invoice>));
                    var sw = new StringWriter();
                    xs.Serialize(sw, partytranscations1, DataBase.ns);
                    Console.WriteLine(sw.ToString());
                    return sw.ToString();


                }
            });
        }
        public static List<flattenentry> DataforPivotAsysc(string pdosname)
        {
            List<Item> itemmasterlist = Item.GetAllItems(pdosname);
            List<Location> locationmasterlist = Location.GetLocations(pdosname);
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                var computeIN1 = db.GetCollection<Invoice>("invoices").FindAll().SelectMany(a => a.invoiceitems);
                List<flattenentry> computeIN = computeIN1.GroupBy(x => new { x.itemid, x.locationid })
                                                .Select(p => new flattenentry
                                                {
                                                    cmpname=pdosname,
                                                    locationid = p.Key.locationid,
                                                    itemid = p.Key.itemid,

                                                    inqty = p.Sum(x => x.qty),
                                                    outqty = 0
                                                })
                                                .ToList();


                var computeOUT1 = db.GetCollection<Invoice>("invoices").FindAll().Where(d => !d.slocationid.Equals(0))
                                    .SelectMany(a => a.invoiceitems);


                List<flattenentry> computeOUT = computeOUT1.GroupBy(x => new { x.itemid, x.locationid })
                                .Select(p => new flattenentry
                                {
                                    cmpname = pdosname,
                                    locationid = p.Key.locationid,
                                    itemid = p.Key.itemid,
                                    inqty = 0,
                                    outqty = p.Sum(x => x.qty)
                                })
                                .ToList();

                var result = computeOUT
                            .Concat(computeIN)
                            .GroupBy(x => new { x.locationid, x.itemid })
                            .Select(p => new flattenentry
                            {
                                locationname = locationmasterlist.FirstOrDefault(loc => loc.id == p.Key.locationid)?.name,
                                locspec = locationmasterlist.FirstOrDefault(loc => loc.id == p.Key.locationid)?.Specification,
                                itemname = itemmasterlist.FirstOrDefault(it => it.id == p.Key.itemid)?.name,
                                groupname = itemmasterlist.FirstOrDefault(it => it.id == p.Key.itemid)?.groupname,
                                categoryname= itemmasterlist.FirstOrDefault(it => it.id == p.Key.itemid)?.Category,
                                locationid = p.Key.locationid,
                                itemid = p.Key.itemid,
                                inqty = p.Sum(x => x.inqty),
                                outqty = p.Sum(x => x.outqty)
                            })
                            .ToList();
                return result;

            }
        }
        public static async Task<List<flatteninvouce>> SimpleInOutAsync(string pdosname)
        {
            return await Task.Run(() =>
            {


                using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
                {
                    var computeIN1 = db.GetCollection<Invoice>("invoices").FindAll().SelectMany(invoice => invoice.invoiceitems
                                        .Select(item => new flatteninvouce
                                        {

                                            date = invoice.date,
                                            edate = invoice.edate,
                                            slocationstr = string.Equals(invoice.vchname, "purchase", StringComparison.OrdinalIgnoreCase) ? invoice.partyname : invoice.slocationstr,
                                            partyinvno = invoice.partyinvno,
                                            partyinvdate = invoice.partyinvdate,
                                            unique1 = invoice.unique1,
                                            vchname = invoice.vchname,
                                            narration = invoice.narration,
                                            itemname = item.itemname,  // Replace with the actual property name in InvoiceItem
                                            inqty = item.qty,  // Replace with the actual property name in InvoiceItem
                                            amt = item.amount // Replace with the actual property name in InvoiceItem
                                        }))
                                    .ToList();
                    return computeIN1.ToList();
                }
            });

        }
        public static string SaveFAInvoices(string pdosname, Invoice inv)
        {
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                var invos = db.GetCollection<Invoice>("fainvoices");

                var latest = invos.FindOne(Query.All(-1));

                int newid = (latest != null) ? latest.id + 1 : 1;


                if (inv != null && inv.id == -1)
                {

                    inv.id = newid;
                    //items.Insert(item);
                    
                }
                else
                {
                    Invoice inv1 = invos.FindById(inv.id);
                    
                }



                invos.Upsert(inv);
                var response = new XElement("ENVELOPE",
                        new XElement("HEADER",
                            new XElement("VERSION", "1"),
                            new XElement("STATUS", "1")
                            ),
                            new XElement("BODY",
                            new XElement("DATA",
                            new XElement("STATUS.LIST",
                            new XElement("STATUS",
                            new XElement("CODE", inv.id),
                            new XElement("DESC", "Ok")))))

                         );

                return response.ToString();
            }
        }


    }
    [XmlRoot("PERSON")]
    public class Person
    {
        [XmlElement("ID")]
        public int id { get; set; }
        [XmlElement("NAME")]
        public string name { get; set; }

        [XmlElement("GSTNO")]
        public string gstno { get; set; }

        [XmlElement("PAN")]
        public string pan { get; set; }

        [XmlElement("ADDRESS1")]
        public string address1 { get; set; }

        [XmlElement("ADDRESS2")]
        public string address2 { get; set; }

        [XmlElement("CITY")]
        public string city { get; set; }

        [XmlElement("STATE")]
        public string state { get; set; }

        [XmlElement("COUNTRY")]
        public string country { get; set; }
        [XmlElement("ZIPCODE")]
        public string zipcode { get; set; }
        [XmlElement("MAILID")]
        public string mailid { get; set; }
        [XmlElement("PHONE")]
        public string phone { get; set; }

        public Person() { }


        public static Person FromXML(string xml)
        {

            XmlSerializer serializer = new XmlSerializer(typeof(Person));
            using (TextReader reader = new StringReader(xml))
            {
                return (Person)serializer.Deserialize(reader);
            }
        }
        public static string SavePerson(string pdosname, Person person)
        {
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                var pss = db.GetCollection<Person>("persons");

                if (person.id.Equals(-1))
                {
                    int newid = pss.Count() + 1;
                    person.id = newid;
                    //items.Insert(item);
                }



                pss.Upsert(person);
                var response = new XElement("ENVELOPE",
                        new XElement("HEADER",
                            new XElement("VERSION", "1"),
                            new XElement("STATUS", "1")
                            ),
                            new XElement("BODY",
                            new XElement("DATA",
                            new XElement("STATUS.LIST",
                            new XElement("STATUS",
                            new XElement("CODE", person.id),
                            new XElement("DESC", "Ok")))))

                         );

                return response.ToString();
            }

        }
        public static string PersonstoXML(string pdosname)
        {
            //using (var db = new LiteDatabase(@"\Data\" + pdosname + "\\SIPL.tdd"))
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                var pers = db.GetCollection<Person>("persons");
                IList<Person> allpersons = pers.FindAll().ToList();
                //return Ok<IList<Order>>(allorder);
                var xs = new XmlSerializer(typeof(List<Person>));
                var sw = new StringWriter();
                xs.Serialize(sw, allpersons, DataBase.ns);

                return sw.ToString();

            }
        }
        public static List<Person> GetListOfPerson(string pdosname)
        {
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                return db.GetCollection<Person>("persons").FindAll().ToList();
            }
        }
    }
    public class flattenentry
    {
        public string cmpname { get; set; }
        public int itemid { get; set; }
        public string itemname { get; set; }
        public int locationid { get; set; }
        public string locationname { get; set; }
        public string locspec { get; set; }
        public double inqty { get; set; }
        public double outqty { get; set; }
        public string groupname { get; set; }
        public string categoryname { get; set; }
        public string uom { get; set; }


    }
    public class flatteninvouce
    {
        //public int id { get; set; }
        public long date { get; set; }
        public string edate { get; set; }
        public string partyinvno { get; set; }
        public string partyinvdate { get; set; }
        public string unique1 { get; set; }
        public string vchname { get; set; }
        public string slocationstr { get; set; }
        //public int slocationid { get; set; }
        public string narration { get; set; }

        //public int itemid { get; set; }
        public string itemname { get; set; }
        //public int locationid { get; set; }
        public string locationname { get; set; }
        //public string locspec { get; set; }
        public double inqty { get; set; }
        public double outqty { get; set; }
        public double amt { get; set; }
    }
    public class InvoiceItem
    {
        [XmlElement("ITEMNAME")]
        public string itemname { get; set; }

        [XmlElement("ITEMID")]
        public int itemid { get; set; }

        [XmlElement("RATE")]
        public double rate { get; set; }

        [XmlElement("QTY")]
        public double qty { get; set; }

        [XmlElement("AMOUNT")]
        public double amount { get; set; }

        //[XmlElement("")]
        public string description { get; set; }

        [XmlElement("LOCATIONSTR")]
        public string locationname { get; set; }

        [XmlElement("LOCATIONID")]
        public int locationid { get; set; }

        public InvoiceItem() { }

        public InvoiceItem(string itemName, int itemID, double rate, double qty, double amount, string description, string locationName, int locationID)
        {
            itemname = itemName;
            itemid = itemID;
            this.rate = rate;
            this.qty = qty;
            this.amount = amount;
            this.description = description;
            this.locationname = locationName;
            this.locationid = locationID;
        }
    }
    [XmlRoot("ASSET")]
    public class Asset
    {
        [XmlElement("ID")]
        public int id { get; set; }

        [XmlElement("ITEMNAME")]
        public string ItemName { get; set; }

        [XmlElement("ITEMID")]
        public int Itemid { get; set; }

        [XmlElement("ASSETDESCRIPTION")]
        public string AssetDescription { get; set; }

        [XmlElement("BARCODE")]
        public string Barcode { get; set; }

        [XmlElement("BRAND")]
        public string Brand { get; set; }

        [XmlElement("CAPACITY")]
        public string Capacity { get; set; }

        [XmlElement("INVNO")]
        public string InvNo { get; set; }

        [XmlElement("INVDATE")]
        public string InvDate { get; set; }

        [XmlElement("INVPARTYNAME")]
        public string InvPartyName { get; set; }

        [XmlElement("INVLEDGER")]
        public string InvLedger { get; set; }

        [XmlElement("INVVALUE")]
        public double InvValue { get; set; }

        [XmlElement("BOOKVALUE")]
        public double BookValue { get; set; }

        [XmlElement("NARRATION")]
        public string narration { get; set; }

        public string isdeleted { get; set; }

        [XmlElement("ASSETLOCATION.LIST")]
        public List<AssetLocation> assetLocations { get; set; } //= new List<AssetLocation>();

        public List<Enquiry> enquiries { get; set; } = new List<Enquiry>();

        public string lastlocationDate()
        {

            //DateTime date = DateTime.ParseExact(InvDate.ToString(), "yyyyMMdd", CultureInfo.InvariantCulture);
            return InvDate;

        }
        public string lastlocation()
        {


            return assetLocations.LastOrDefault().LocatedAt;

        }
        public string GetLastInsDate()
        {
            return enquiries.LastOrDefault(a => a.typestr == "insurance").remDate.ToString();
        }
        public Asset() { }

        public Asset(Asset incomplete)
        {
            ItemName = incomplete.ItemName;
            Itemid = incomplete.Itemid;
            AssetDescription = incomplete.AssetDescription;
            Brand = incomplete.Brand;
            Capacity = incomplete.Capacity;
            InvNo = incomplete.InvNo;
            InvDate = incomplete.InvDate;
            InvPartyName = incomplete.InvPartyName;
            InvLedger = incomplete.InvLedger;
            InvValue = incomplete.InvValue;
            BookValue = incomplete.BookValue;
            this.assetLocations = incomplete.assetLocations;
        }
        public static Asset GetAsset(int pid, string pdosname)
        {
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                return db.GetCollection<Asset>("assets").FindById(pid);
            }
        }
        public static Asset FromXML(string xml)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(Asset));
            using (TextReader reader = new StringReader(xml))
            {
                return (Asset)serializer.Deserialize(reader);
            }
        }

        public static string SaveAsset(string pdosname, Asset asset)
        {
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                var assetss = db.GetCollection<Asset>("assets");

                if (asset.id.Equals(-1))
                {
                    int newid = assetss.Count() + 1;
                    asset.id = newid;
                    //items.Insert(item);
                }



                assetss.Upsert(asset);
                var response = new XElement("ENVELOPE",
                        new XElement("HEADER",
                            new XElement("VERSION", "1"),
                            new XElement("STATUS", "1")
                            ),
                            new XElement("BODY",
                            new XElement("DATA",
                            new XElement("STATUS.LIST",
                            new XElement("STATUS",
                            new XElement("CODE", asset.id),
                            new XElement("DESC", "Ok")))))

                         );

                return response.ToString();
            }

        }
        public static async Task<string> DeleteAssetAsync(int pid,string preson, string dbname)
        {
            return await Task.Run(() =>
            {
                using (var db = new LiteDatabase(@"Filename=" + Program.apppath + dbname + @"\SIPL.tdd;connection=shared;"))
                {
                    var collection = db.GetCollection<Invoice>("fainvoice");
                    var assinvoice = collection.FindOne(a => a.invoiceitems.Where(i => i.itemid == pid).Any());
                    if (assinvoice != null)
                    {
                        //return "Invoice item does not exist";
                        return new XElement("status", "Some Transactions might be in DB").ToString();


                    }
                    else
                    {

                        //return "Invoice item exists";
                        Asset a = new Asset { id = pid, isdeleted = "yes",narration= preson };

                        db.GetCollection<Asset>("assets").Upsert(a);
                        return new XElement("status", "Deleted Successfully").ToString();
                    }
                }


            });
        }
        public static async Task<List<Enquiry>> UpdateEnquiryAsync(int pid, string ptxt, string dbname)
        {
            return await Task.Run(() =>
            {
                using (var db = new LiteDatabase(@"Filename=" + Program.apppath + dbname + @"\SIPL.tdd;connection=shared;"))
                {
                    var assetvar = db.GetCollection<Asset>("assets").FindById(pid);
                    if (assetvar != null)
                    {
                        Enquiry enquiry = new Enquiry(ptxt);
                        //enquiry.enqtxt = ptxt;
                        assetvar.enquiries.Add(enquiry);
                        db.GetCollection<Asset>("assets").Update(assetvar);
                        List<Enquiry> list = assetvar.enquiries.ToList();
                        return list;
                    }
                    else
                    {
                        return null;
                    }
                }
            });
        }
        public static async Task<Asset> UpdateEnquiryExAsync(int pid, EnquiryModel em, string dbname)
        {
            return await Task.Run(() =>
            {
                using (var db = new LiteDatabase(@"Filename=" + Program.apppath + dbname + @"\SIPL.tdd;connection=shared;"))
                {


                    var assetvar = db.GetCollection<Asset>("assets").FindById(pid);
                    if (assetvar != null)
                    {
                        Enquiry enquiry = new Enquiry(em.Typestr, em.StringValue, em.RemDate);
                        //enquiry.enqtxt = ptxt;
                        assetvar.enquiries.Add(enquiry);
                        db.GetCollection<Asset>("assets").Update(assetvar);
                        return assetvar;
                    }
                    else
                    {
                        return null;
                    }
                }
            });
        }
        public async static Task<string> SaveManyAssetsAsync(string pdosname, int clone, Asset asset)
        {
            return await Task.Run(() =>
            {


                using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
                {

                    var item = db.GetCollection<Item>("items").Find(x => x.name.Equals(asset.ItemName));
                    string pfix = item.FirstOrDefault().prefix;
                    string sfix = item.FirstOrDefault().suffix;
                    var prevassets = db.GetCollection<Asset>("assets");
                    int prevassets1 = prevassets.Find(o => o.ItemName.Equals(asset.ItemName)).Count();
                    int newid = prevassets.Count();  //Find(o => o.Itemid.Equals(asset.Itemid)).Count();
                    Console.WriteLine(newid);
                    List<Asset> newassets = new List<Asset>();
                    int number = 0;
                    for (int i = 0; i < clone; i++)
                    {
                        Asset newAsset = new Asset(asset);
                        number = i + 1 + prevassets1;

                        newAsset.id = newid + i + 1;

                        newAsset.Barcode = string.Concat(pfix, number.ToString($"D{5}"), sfix);
                        newassets.Add(newAsset);
                    }
                    Console.WriteLine(JsonConvert.SerializeObject(newassets, Newtonsoft.Json.Formatting.Indented));

                    prevassets.InsertBulk(newassets);
                    var response = new XElement("ENVELOPE",
                    new XElement("HEADER",
                        new XElement("VERSION", "1"),
                        new XElement("STATUS", "1")),
                        new XElement("BODY",
                        new XElement("DATA",
                        new XElement("STATUS.LIST", new XElement("STATUS",
                        new XElement("CODE", 1),
                        new XElement("DESC", newassets.Count + " Inserted")))))
                        );
                    return response.ToString();
                }
            });
        }

        public static string AssetstoXML(string path, string pdosname)
        {
            //using (var db = new LiteDatabase(@"\Data\" + pdosname + "\\SIPL.tdd"))
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                var locs = db.GetCollection<Asset>("assets");
                List<Asset> alllassets = locs.FindAll().ToList();

                var fainvos1 = db.GetCollection<Invoice>("fainvoices");

                var fainvos = fainvos1
                    .FindAll()
                    .SelectMany(a => a.invoiceitems, (a, invoiceitem) => new ADatewiseinvoice
                    {
                        qitemid = invoiceitem.itemid,
                        locationname = invoiceitem.locationname,
                        date = a.edate


                        
                    })
                    .GroupBy(item => item.qitemid)
                    .ToDictionary(
                        group => group.Key,
                        group => group.ToList()
                    );

                foreach (var asset in alllassets)
                {
                    if (fainvos.TryGetValue(asset.id, out var assetLocations))
                    {
                        asset.assetLocations.AddRange(assetLocations.Select(location => new AssetLocation
                        {
                            LocatedAt = location.locationname,
                            Date = location.date
                            // ...
                        })); ;
                    }
                }



                var xs = new XmlSerializer(typeof(List<Asset>));
                var sw = new StringWriter();
                xs.Serialize(sw, alllassets, DataBase.ns);
                return sw.ToString();
                //return JsonConvert.SerializeObject(fainvos);
            }
        }
        public static List<Asset> ListofUpdatedAssetstoJsonobj(string pdosname)
        {
            //using (var db = new LiteDatabase(@"\Data\" + pdosname + "\\SIPL.tdd"))
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                var locs = db.GetCollection<Asset>("assets");
                List<Asset> alllassets = locs.FindAll().ToList();

                var fainvos1 = db.GetCollection<Invoice>("fainvoices");

                var fainvos = fainvos1
                    .FindAll()
                    .SelectMany(a => a.invoiceitems, (a, invoiceitem) => new ADatewiseinvoice
                    {
                        qitemid = invoiceitem.itemid,
                        locationname = invoiceitem.locationname,
                        date = a.edate


                        // ...
                    })
                    .GroupBy(item => item.qitemid)
                    .ToDictionary(
                        group => group.Key,
                        group => group.ToList()
                    );

                foreach (var asset in alllassets)
                {
                    if (fainvos.TryGetValue(asset.id, out var assetLocations))
                    {
                        asset.assetLocations.AddRange(assetLocations.Select(location => new AssetLocation
                        {
                            LocatedAt = location.locationname,
                            Date = location.date
                            // ...
                        })); ;
                    }
                }



                return alllassets;       //JsonConvert.SerializeObject(fainvos);
            }
        }
        public static List<Asset> AssetsList(string path, string pdosname)
        {
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                var locs = db.GetCollection<Asset>("assets");
                IList<Asset> alllassets = locs.FindAll().ToList();

                return alllassets.ToList();
            }
        }
        public static string FAInvoicestoXML(string pdosname, string format)
        {
            using (var db = new LiteDatabase(@"Filename=" + Program.apppath + pdosname + @"\SIPL.tdd;connection=shared;"))
            {
                var fainvos = db.GetCollection<Invoice>("fainvoices");
                IList<Invoice> allinvoices = fainvos.FindAll().ToList();
                //return Ok<IList<Order>>(allorder);

                if (format.Equals("xml"))
                {

                    var xs = new XmlSerializer(typeof(List<Invoice>));
                    var sw = new StringWriter();
                    xs.Serialize(sw, allinvoices, DataBase.ns);
                    return sw.ToString();
                }
                else
                {
                    Dictionary<string, IList<Invoice>> dict = new Dictionary<string, IList<Invoice>>();
                    dict.Add("allinvoices", allinvoices);
                    return JsonConvert.SerializeObject(dict);
                }
            }
        }

    }

    public class AssetLocation
    {
        [XmlElement("LOCATEDAT")]
        public string LocatedAt { get; set; }

        [XmlElement("DATE")]
        public string Date { get; set; }

        public AssetLocation() { }

        public AssetLocation(string locatedAt, string date)
        {
            LocatedAt = locatedAt;
            Date = date;
        }
    }

    public class Enquiry
    {
        public string typestr { get; set; }
        public string enqtxt { get; set; }
        public DateTime remDate { get; set; }

        public string byuser { get; set; }
        public DateTime attime { get; set; }

        public Enquiry() { }

        public Enquiry(string enqtxt, string byuser)
        {
            this.enqtxt = enqtxt;
            this.byuser = byuser;
            this.attime = attime;
        }
        public Enquiry(string enqtxt)
        {
            this.enqtxt = enqtxt;
            //this.byuser = string.IsNullOrEmpty(originalString) ? "Default Value" : originalString;
            this.byuser = "admin";
            this.attime = DateTime.Now;

        }
        public Enquiry(string type, string enqtxt, DateTime remdate)
        {
            this.typestr = type;
            this.enqtxt = enqtxt;
            this.remDate = remdate;
            this.byuser = "admin";
            this.attime = DateTime.Now;
        }
    }
    public class aInvoice
    {
        public int itemid { get; set; }
        public string itemname { get; set; }
        public int locationid { get; set; }
        public string locationname { get; set; }
        public string locationspec { get; set; }
        public double inqty { get; set; }
        public double outqty { get; set; }

        public aInvoice()
        {
        }

        public aInvoice(int itemid, string itemname, int locationid, string locationname, double inqty, double outqty)
        {
            this.itemid = itemid;
            this.itemname = itemname;
            this.locationid = locationid;
            this.locationname = locationname;
            this.inqty = inqty;
            this.outqty = outqty;
        }
        public aInvoice(int itemid, string itemname, int locationid, string locationname, double inqty, double outqty, string locspec)
        {
            this.itemid = itemid;
            this.itemname = itemname;
            this.locationid = locationid;
            this.locationname = locationname;
            this.inqty = inqty;
            this.outqty = outqty;
            this.locationspec = locspec;
        }
    }
    public class ADatewiseinvoice
    {
        public string date { get; set; }
        public int qitemid { get; set; }
        public string itemname { get; set; }
        public int locationid { get; set; }
        public string locationname { get; set; }
        public double qty { get; set; }
        public double rate { get; set; }
        public double amt { get; set; }
        public string PartyName { get; set; }
        public string UniqID { get; set; }
        public string VchName { get; set; }
        public string UOM { get; set; }
       
        public string cmpname { get; set; }
        public string cmpno { get; set; }
        public ADatewiseinvoice()
        {
        }
    }

    public class InvData        //this is for Json request
    {

        public List<Person> persons { get; set; }
        public List<Location> locations { get; set; }
        public List<Item> items { get; set; }
        public List<Invoice> invoices { get; set; }


    }
}
