﻿using Microsoft.AspNetCore.Mvc;
using MountCarmelweb.Models;
using Newtonsoft.Json;
using System.Diagnostics;
using System.Formats.Asn1;
using System.Globalization;
using System.Xml.Linq;
using Windows.Devices.Usb;

using Newtonsoft.Json.Linq;
using System.Text;
using System;
using Microsoft.AspNetCore.DataProtection.KeyManagement;
using Humanizer;
using System.Collections.Generic;
using System.Net.NetworkInformation;

namespace MountCarmelweb.Controllers
{
    public class HomeController : Controller
    {
        private readonly IWebHostEnvironment _env;


        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger, IWebHostEnvironment env)
        {
            _env = env;
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public IActionResult AllPurchaseTransactions()
        {
            string basePath = _env.WebRootPath;
            List<Asset> assets = Asset.AssetsList(basePath, "001");
            ViewData["assetslist"] = assets;
            return View();
        }

        public ActionResult YourAction()
        {
            // Generate or retrieve your XML data
            XElement xmlData = new XElement("Root",
                new XElement("Element1", "Value1"),
                new XElement("Element2", "Value2"));

            // Serialize the XML data to a string
            string xmlString = xmlData.ToString();

            // Return the XML response
            return Content(xmlString, "application/xml");
        }
        public IActionResult FARegister()
        {
            return View();
        }
        public IActionResult ShowIndividualAsset()
        {

            return View();
        }

        public IActionResult createFA() 
        {
            List<Item> items = Item.GetFAItems("001");
            ViewBag.itemList = items;
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult createFA(Asset asset)
        {
            if (ModelState.IsValid)
            {
                Asset.SaveAsset("001", asset);
               
                Console.WriteLine(JsonConvert.SerializeObject(asset));
                //return RedirectToAction(nameof(Index));
            }
            return View(asset);
        }

        public IActionResult ProcessCSV()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> ProcessCSV(IFormFile csvFile)
        {
            if (csvFile != null && csvFile.Length > 0)
            {
                using (var reader = new StreamReader(csvFile.OpenReadStream()))
                {
                    var totalLines = 0;
                    var progress = 0;
                    var items = new List<Item>();

                    // Read all lines to calculate total lines (excluding the header)
                    while (!reader.EndOfStream)
                    {
                        await reader.ReadLineAsync();
                        totalLines++;
                    }

                    // Reset the stream position and skip the header
                    reader.BaseStream.Seek(0, SeekOrigin.Begin);
                    reader.DiscardBufferedData();
                    await reader.ReadLineAsync();

                    while (!reader.EndOfStream)
                    {
                        var line = await reader.ReadLineAsync();
                        var lineAttrs = line.Split(',');

                        Item item = new Item(lineAttrs[0], lineAttrs[1], lineAttrs[2], lineAttrs[3]);
                        //items.Add(item);

                        // Calculate progress
                        progress++;
                        var progressPercentage = (int)(((double)progress / totalLines) * 100);

                        // Check if the header already exists before adding it
                        /*if (!HttpContext.Response.Headers.ContainsKey("X-Progress"))
                        {
                            HttpContext.Response.Headers.Add("X-Progress", progressPercentage.ToString());
                        }*/

                        //Console.WriteLine(JsonConvert.SerializeObject(item));
                        if (DataBase.IsDataBaseExists("001")){


                            Console.WriteLine(item.name + " " + Item.SingleSave("001", item));
                        }
                        
                       
                        //return Content(progressPercentage.ToString(), "text/plain");

                    }

                    // Processed all lines, now you have the 'items' list ready
                }
            }

            // Add additional processing logic here

            return Ok(); // Signal that the processing is complete
        }
        public IActionResult ProcessLocationCSV()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> ProcessLocationCSV(IFormFile csvFile)
        {
            if (csvFile != null && csvFile.Length > 0)
            {
                using (var reader = new StreamReader(csvFile.OpenReadStream()))
                {
                    var totalLines = 0;
                    var progress = 0;
                    

                    // Create a StringBuilder to store the updated CSV data
                    var updatedCsvData = new StringBuilder();

                    // Read all lines to calculate total lines (excluding the header)
                    while (!reader.EndOfStream)
                    {
                        await reader.ReadLineAsync();
                        totalLines++;
                    }

                    // Reset the stream position and skip the header
                    reader.BaseStream.Seek(0, SeekOrigin.Begin);
                    reader.DiscardBufferedData();
                    await reader.ReadLineAsync();

                    while (!reader.EndOfStream)
                    {
                        var line = await reader.ReadLineAsync();
                        var lineAttrs = line.Split(',');

                        Location loc = new Location( lineAttrs[0], lineAttrs[1]);

                        // Update the status of the item as needed
                        // For example, you can set a new status field or modify an existing one
                        if(!string.IsNullOrEmpty(lineAttrs[0]) || !string.IsNullOrEmpty(lineAttrs[1]))
                        {
                            string dbresp = Location.CreateLocationAsync(loc, "001").Result;
                            updatedCsvData.AppendLine($"{loc.name},{loc.Specification},{dbresp}");
                        }
                        else
                        {
                            updatedCsvData.AppendLine("For Creating Location/Godown both fields are necessary");
                        }
                        
                        

                        // Append the updated line to the StringBuilder
                       

                        // Calculate progress
                        progress++;
                        Console.WriteLine(JsonConvert.SerializeObject(loc));
                    }

                    // Create a byte array from the updated CSV data
                    var memoryStream = new MemoryStream(Encoding.UTF8.GetBytes(updatedCsvData.ToString()));

                    // Return the updated CSV file for download
                    //return File(csvBytes, "text/csv", "updated_Locations.csv");
                    return File(memoryStream, "text/csv", "updated_Locations.csv");
                }
            }

            // Handle the case where no CSV file was uploaded
            return BadRequest("No CSV file uploaded.");
        }
        public IActionResult StkItems()
        {
            
            return View();
        }
        [HttpGet]
        public IActionResult GetAllItems()
        {
            List<Item> items = Item.GetAllItems("001");
            return new JsonResult(items);
        }

        public IActionResult ItemDetails(int id)
        {
            Item item = Item.GetItem("001", id);
            //ViewBag.Id = id;
            
            return View(item);
        }

        public IActionResult Locations()
        {
            
            return View();
        }
        [HttpGet]
        public IActionResult GetAllLocations()
        {
            List<Location> locations = Location.GetLocations("001");
            return new JsonResult(locations);
        }
        public IActionResult LocationDetails(int id) 
        {
            Location location = Location.GetLocation(id,"001");
            return View(location);
        }
        public IActionResult ItemLocationwisepivot()
        {
           
           
            return View();
        }
        [HttpGet]
        public IActionResult GetFARegister()
        {
            List<Asset> faregister = Asset.ListofUpdatedAssetstoJsonobj("001");
            return new JsonResult(faregister);
        }

        public IActionResult FAHistory(int id)
        {
            var asset = Asset.GetAsset(id,"001");
            if (asset == null)
            {
                return NotFound();
            }
            
            return View(asset);
        }

        [HttpPost]
        public IActionResult UpdateEnquiry(int id, [FromBody] string ptext)
        {
            List<Enquiry> allenq = Asset.UpdateEnquiryAsync(id, ptext, "001").Result;
            //return Json(new { result = "Received: " + ptext });
            var logData = new { Id = id, PText = ptext };
            _logger.LogInformation(JsonConvert.SerializeObject(logData));
            _logger.LogInformation(JsonConvert.SerializeObject(allenq));
            return Json(allenq);
        }
        [HttpGet]
        public ActionResult ProcessPurchaseCSV()
        {
            return View();
        }
        [HttpPost]
        public IActionResult ProcessPurchaseCSV([FromBody] Object invData)
        {
            //Console.WriteLine("ok" + invData);
            string jsonContent = invData.ToString();
            InvData invData1 = JsonConvert.DeserializeObject<InvData>(jsonContent);
            Console.WriteLine(invData1.invoices.Count);
            try
            {

                if(invData == null )
                {
                    //return BadRequest("Input data is null or the 'voucher' array is missing.");
                   
                }
                return  Json(new {data1 = DataBase.SaveAllBulkObjAsync(invData1,"001").Result });
                //return Json(invData1.invoices.Count);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }

        }
        [HttpGet]
        public IActionResult ProcessTransfervouchers()
        {
            ViewBag.ItemList = Item.GetAllItems("001");
            ViewBag.LocationList = Location.GetLocations("001");
            ViewBag.PrevTransactions = Invoice.GetExistingbothInvoicesList("001");
            //var invData = new InvData();
            return View();
        }
        [HttpPost]
        public IActionResult ProcessTransfervouchers([FromBody] Object pinv)
        {
            try
            {
                //Console.WriteLine("Received data: " + pinv);
                string jsonContent = pinv.ToString();
                List<Invoice> invoices = JsonConvert.DeserializeObject<List<Invoice>>(jsonContent);
                

                return Json(new { data = DataBase.SaveTransferVchsAsync(invoices, "001").Result });

                //return Json(new { success = true, data = invoices });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.Message });
            }
        }
        public IActionResult Masterreport()
        {
            return View();
        }
        public IActionResult tddHandler()
        {
            
            //return Json(new { data = data });
            return Json(Invoice.SimpleInOutAsync("001").Result);
        }

    }

    public class EnquiryModel
    {
        
        public string Typestr { get; set; }
        public string StringValue { get; set; }
        public DateTime RemDate { get; set; }
        public EnquiryModel() { }

        public EnquiryModel(string typestr, string stringValue, DateTime remDate)
        {
            Typestr = typestr;
            StringValue = stringValue;
            RemDate = remDate;
        }
    }

}