﻿
using System.Reflection;
using System.Web.Http;


namespace MountCarmelweb.APIController
{
    [Route("api/[controller]")]
    
    public class ValuesController : ApiController
    {
        // GET: api/<ValuesController>
        //https://localhost:4581/api/values/get
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }



        // POST api/<ValuesController>
        [HttpPost]
        public IHttpActionResult Post([FromBody] Invoice inv)
        {
            if (inv == null)
            {
                return BadRequest("Invalid data.");
            }

            // Process the model data here

            return Ok("Data received and processed.");
        }


    }
}
