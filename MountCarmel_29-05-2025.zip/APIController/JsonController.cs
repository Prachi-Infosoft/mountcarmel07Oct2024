﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MountCarmelweb.Controllers;
using System.Text;

namespace MountCarmelweb.APIController
{
    [Route("api/[controller]")]
    [ApiController]
    public class JsonController : ControllerBase
    {
        //https://localhost:4581/api/json/ItemwiseLocationwiseInOut
        [HttpGet]
        [Route("ItemwiseLocationwiseInOut")]
        public async Task<string> ItemwiseLocationwiseClosingstock(string companyno = "001")
        {
            return await Task.Run(() =>
            {
                /*HttpResponseMessage response = Request.CreateResponse();
                response.Headers.Add("Access-Control-Allow-Origin", "*");
                response.Headers.Add("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
                response.Headers.Add("Access-Control-Allow-Headers", "Content-Type");
                response.Headers.Add("Access-Control-Allow-Credentials", "true");
                response.Content = new StringContent(Invoice.ItemsWithClosingBalancetoXML(companyno), Encoding.UTF8, "application/json");*/
                /*return new HttpResponseMessage()
                {
                    
                    Content = new StringContent(Invoice.ItemsWithClosingBalancetoXML(companyno), Encoding.UTF8, "application/json")
                };*/
                ContentResult contentResult = new ContentResult
                {
                    //Content = Invoice.ItemsWithClosingBalancetoXML(companyno),
                    Content ="",
                    //Content= xmlData.ToString(),

                    ContentType = "application/json"
                };
                return contentResult.Content;


            });
        }
        //https://localhost:4581/api/json/getinoutinjson?companyno=001
        [HttpGet]
        [Route("getinoutinjson")]
        public IActionResult GetInOutJSON(string companyno = "001")
        {
            var result = new { data = Invoice.GetInOutJsonObject(companyno) };
            return Ok(result);
        }
        //https://localhost:4581/api/json/getItemwiseLocationwise?companyno=001
        [HttpGet]
        [Route("getItemwiseLocationwise")]
        public IActionResult getItemwiseLocationwise(string companyno = "001")
        {
            var data =  Invoice.DataforPivotAsysc(companyno);
            var result = new {data=data};

            return Ok(result);
            
        }
        //SelectedGodownInOut
        //https://localhost:4581/api/json/SelectedLocationHistory?companyno=001&locid=1
        [HttpGet]
        [Route("SelectedLocationHistory")]
        public async Task<string> SelectedLocationHistory(int locid, long fromdate = 1, long todate = 22000000, string companyno = "001")
        {
            return await Task.Run(() =>
            {
                ContentResult contentResult = new ContentResult
                {
                    Content = Invoice.SelectedGodownInOut(companyno, locid,fromdate,todate),
                    //Content= xmlData.ToString(),

                    ContentType = "application/json"
                };
                return contentResult.Content;
            });
        }
        //https://localhost:4581/api/json/selectedlocationbal?companyno=001&locid=1
        [HttpGet]
        [Route("selectedlocationbal")]
        public async Task<string> selectedlocationbal(int locid, string companyno = "001")
        {
            if (locid == 0) { };
            return await Task.Run(() =>
            {
                ContentResult contentResult = new ContentResult
                {
                    Content = Invoice.AllItemsWithSGInOut(companyno,locid),
                    //Content = locid.ToString(),
                    ContentType = "application/json"
                };
                return contentResult.Content;
            });
        }

        //https://localhost:4581/api/json/GetItemstransactions?companyno=001&locid=1
        [HttpGet]
        [Route("GetItemstransactions")]
        public async Task<List<Invoice>> GetItemstransactions(int locid, string companyno = "001")
        {
            return await Task.Run(() =>
            {
                Console.WriteLine(locid);
                List<Invoice> invoices = Invoice.SelectedItemsTransactions("001", locid);
                return invoices;
            });
        }
        //https://localhost:4581/api/json/GetLocationtransactions?companyno=001&locid=1
        [HttpGet]
        [Route("GetLocationtransactions")]
        public List<flattenentry> GetLocationstransactions(int locid, string companyno = "001")
        {
            return Invoice.SelectedGodownInOutAsync(companyno,locid).Result;
        }

        //https://localhost:4581/api/json/GetFARegister?companyno=001
        [HttpGet]
        [Route("GetFARegister")]
        public List<Asset> GetLatestAssetRegister(string companyno = "001")
        {
            return Asset.ListofUpdatedAssetstoJsonobj(companyno);
        }

        //https://localhost:4581/api/json/UpdateAdditionalDetails?id=1
        [HttpPost]
        [Route("UpdateAdditionalDetails")]
        public Asset UpdateAdditionalDetails(int id, [FromBody] EnquiryModel model)
        {
            return (Asset.UpdateEnquiryExAsync(id,model,"001").Result);
        }

        
        
    }
}
