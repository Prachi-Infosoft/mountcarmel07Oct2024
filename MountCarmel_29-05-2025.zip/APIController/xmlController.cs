﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Globalization;
using System.Text;
using System.Web.Http.Results;
using System.Xml;
using System.Xml.Linq;

namespace MountCarmelweb.APIController
{
    [Route("api/[controller]")]
    [ApiController]
    public class xmlController : ControllerBase
    {
        /*private readonly IWebHostEnvironment _env;

        public xmlController(IWebHostEnvironment env)
        {
            _env = env;
            System.IO.Directory.CreateDirectory("Data");
        }*/

        //https://localhost:4581/api/xml
        [HttpGet]
        public async Task<string> Get()
        {
            var response = new XElement("Response");
            return await Task.Run(() =>
            {
                response.Add(
                    new XElement("License", "000004581"),
                    new XElement("LicenseType", "TDDDB Maount Karmel Server"),
                    new XElement("Version", "1.0"),
                    //new XElement("PATH", DataBase.DBPath),
                    new XElement("EXEPATH", System.AppDomain.CurrentDomain.BaseDirectory),
                    new XElement("WEBFolder", Program.apppath),
                    new XElement("Status", "Active"),
                    new XElement("code", "0"),
                    new XElement("ServerTime", DateTime.Now.ToString("dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture))
                    );
                ContentResult contentResult = new ContentResult
                {
                    Content = response.ToString(),

                    ContentType = "text/xml"
                };
                return contentResult.Content;
            });

        }
        //https://localhost:4581/api/xml/serverstatus
        [HttpGet]
        [Route("serverstatus")]
        public async Task<string> serverstatus()
        {
            string basePath = Program.apppath;

            var response = new XElement("Response");
            return await Task.Run(() =>
            {


                response.Add(
                   new XElement("License", "000004581"),
                   new XElement("LicenseType", "TDDDB Maount Karmel Server"),
                   new XElement("Version", "1.0"),
                   //new XElement("PATH", DataBase.DBPath),
                   new XElement("EXEPATH", System.AppDomain.CurrentDomain.BaseDirectory),
                   new XElement("WEBFolder",Program.apppath),
                   new XElement("Status", "Active"),
                   new XElement("code", "0"),
                   new XElement("ServerTime", DateTime.Now)
                   );

                ContentResult contentResult = new ContentResult
                {
                    Content = response.ToString(),

                    ContentType = "text/xml"
                };
                return contentResult.Content;

            });
        }

        //https://localhost:4581/api/xml/CreatenewDatabase
        [HttpPost]
        [Route("CreatenewDatabase")]
        public async Task<string> CreatenewDatabaseAsync([FromBody] XElement xmlData)
        {
            string basePath = Program.apppath;
            
            return await Task.Run(() =>
            {

           
            

                XmlDocument doc = new XmlDocument();
                string xmlString = xmlData.ToString();
                doc.LoadXml(xmlString);
               
                ContentResult contentResult = new ContentResult
                {
                    Content = DataBase.CreateDataBase(doc),
                    //Content= xmlData.ToString(),

                     ContentType = "text/xml"
                };
                return contentResult.Content;
            });


        }
        //https://localhost:4581/api/XML/ListOfDataBases
        [HttpGet]
        [Route("ListOfDataBases")]
        public string ListOfDataBases()
        {
            Encoding encoding = Encoding.UTF8; // Specify the desired encoding
            byte[] contentBytes = encoding.GetBytes(DataBase.DataBasetoXML());
            string encodedContent = encoding.GetString(contentBytes);

            ContentResult contentResult = new ContentResult
            {
                Content = encodedContent,
                ContentType = "text/xml",
                
            };
            return contentResult.Content;


        }
        //--------------------
        //http://localhost:4581/xml/PostItem
        [HttpPost]
        [Route("PostItem")]
        public string PostItem([FromBody] XElement xmlData, string companyno="001")
        {
            //string basePath = Program.apppath;
            //string companyno = Request.Query["companyno"];
            //Item item = new Item();
            var doc = new XmlDocument();
            doc.LoadXml(xmlData.ToString());

            Encoding encoding = Encoding.UTF8; // Specify the desired encoding
            byte[] contentBytes = encoding.GetBytes(Item.SaveItem(companyno, Item.FromXML(doc.DocumentElement.OuterXml)).Result);
            string encodedContent = encoding.GetString(contentBytes);

            ContentResult contentResult = new ContentResult
            {
                Content = encodedContent,
                ContentType = "text/xml",

            };
            return contentResult.Content;


        }
        
        //https://localhost:4581/api/XML/ListOfAllItems
        [HttpGet]
        [Route("ListOfAllItems")]
        public async Task<string> ListOfAllItems(string companyno ="001")
        {
            return await Task.Run(() =>
            {


                //string basePath = Program.apppath;
                //string companyno = Request.Query["companyno"] ;

                Encoding encoding = Encoding.UTF8; // Specify the desired encoding
                byte[] contentBytes = encoding.GetBytes(Item.ItemtoXML(companyno));
                string encodedContent = encoding.GetString(contentBytes);
                ContentResult contentResult = new ContentResult
                {
                    Content = encodedContent,
                    ContentType = "text/xml",

                };
                return contentResult.Content;
            });
        }
        //https://localhost:4581/api/XML/deleteitemmaster?companyno=001&id=23
        [HttpGet]
        [Route("deleteitemmaster")]
        public string delteitem(int id, string companyno = "001")
        {
            

            Encoding encoding = Encoding.UTF8; // Specify the desired encoding
            byte[] contentBytes = encoding.GetBytes(Item.DeleteItemAsync(id,companyno).Result);
            string encodedContent = encoding.GetString(contentBytes);

            ContentResult contentResult = new ContentResult
            {
                Content = encodedContent,
                ContentType = "text/xml",

            };
            return contentResult.Content;
        }

            
        //------------------------Location
        //http://localhost:4581/xml/CreatenewLocation
        [HttpPost]
        [Route("CreatenewLocation")]
        public async Task<string> PostLocation([FromBody] XElement xmlData, string companyno = "001")
        {

            string basePath = Program.apppath;
            //string companyno = Request.Query["companyno"];


            var doc = new XmlDocument();
            doc.LoadXml(xmlData.ToString());

            return await Task.Run(() =>
            {

                Encoding encoding = Encoding.UTF8; // Specify the desired encoding
                byte[] contentBytes = encoding.GetBytes(Location.SaveLocation(companyno, Location.FromXML(doc.DocumentElement.OuterXml)));
                string encodedContent = encoding.GetString(contentBytes);

                ContentResult contentResult = new ContentResult
                {
                    Content = encodedContent,
                    ContentType = "text/xml",

                };
                return contentResult.Content;
            });
        }
        //https://localhost:4581/api/xml/ListOfAllLocations
        [HttpGet]
        [Route("ListOfAllLocations")]
        public async Task<string> ListOfAllLocations(string companyno = "001")
        {
            string basePath = Program.apppath;
            //string companyno = Request.Query["companyno"];
            return await Task.Run(() =>
            {
                Encoding encoding = Encoding.UTF8; // Specify the desired encoding
                byte[] contentBytes = encoding.GetBytes(Location.LocationtoXML(companyno));
                string encodedContent = encoding.GetString(contentBytes);

                ContentResult contentResult = new ContentResult
                {
                    Content = encodedContent,
                    ContentType = "text/xml",

                };
                return contentResult.Content ;
            });

        }
        //https://localhost:4581/api/XML/deletelocationmaster?companyno=001&id=23
        [HttpGet]
        [Route("deletelocationmaster")]
        public string deltelocation(int id, string companyno = "001")
        {


            Encoding encoding = Encoding.UTF8; // Specify the desired encoding
            byte[] contentBytes = encoding.GetBytes(Location.DeleteLocationAsync(id, companyno).Result);
            string encodedContent = encoding.GetString(contentBytes);

            ContentResult contentResult = new ContentResult
            {
                Content = encodedContent,
                ContentType = "text/xml",

            };
            return contentResult.Content;
        }

        //------------------Invoice
        //https://localhost:4581/api/xml/CreatenewInvoice
        [HttpPost]
        [Route("CreatenewInvoice")]
        public async Task<string> CreatenewInvoice([FromBody] XElement xmlData, string companyno = "001")
        {
            
            


            var doc = new XmlDocument();
            doc.LoadXml(xmlData.ToString());
            return await Task.Run(() =>
            {

                Encoding encoding = Encoding.UTF8; // Specify the desired encoding
                byte[] contentBytes = encoding.GetBytes(Invoice.SaveInvoice(companyno, Invoice.FromXML(doc.DocumentElement.OuterXml)));
                //byte[] contentBytes = encoding.GetBytes(xmlData.ToString());
                string encodedContent = encoding.GetString(contentBytes);

                ContentResult contentResult = new ContentResult
                {
                    Content = encodedContent,
                    ContentType = "text/xml",

                };
                return contentResult.Content;
            });

        }

        //http://localhost:4581/xml/ListOfAllInvoices?companyno=001&fromdate=20230101&todate=20230331
        [HttpGet]
        [Route("ListOfAllInvoices")]
        public async Task<string> ListOfAllInvoices(long fromdate = 1, long todate = 22000000, string companyno = "001")
        {
            return await Task.Run(() =>
            {

                Encoding encoding = Encoding.UTF8; // Specify the desired encoding
                byte[] contentBytes = encoding.GetBytes(Invoice.InvoicetoXML(companyno, "xml",fromdate,todate));
                string encodedContent = encoding.GetString(contentBytes);

                ContentResult contentResult = new ContentResult
                {
                    Content = encodedContent,
                    ContentType = "text/xml",

                };
                return contentResult.Content;
                /*return new HttpResponseMessage()
                {
                    Content = new StringContent(Invoice.InvoicetoXML(companyno, "xml"), Encoding.UTF8, "application/xml")
                };*/
            });

        }

        //http://localhost:4581/xml/ListOfSelectedItemInvoices?db=001&sid=4
        [HttpGet]
        [Route("ListOfSelectedItemInvoices")]
        public async Task<string> ListOfSelectedItemInvoices([FromQuery] int sid, long fromdate = 1, long todate = 22000000, string db = "001")
        {
            return await Task.Run(() =>
            {

                Encoding encoding = Encoding.UTF8; // Specify the desired encoding
                byte[] contentBytes = encoding.GetBytes(Invoice.SelecteditemInvoicetoXML(db, sid,"xml",fromdate,todate));
                string encodedContent = encoding.GetString(contentBytes);

                ContentResult contentResult = new ContentResult
                {
                    Content = encodedContent,
                    ContentType = "text/xml",

                };
                return contentResult.Content;

                /*return new HttpResponseMessage()
                {
                    Content = new StringContent(Invoice.SelecteditemInvoicetoXML(db, sid, "xml"), Encoding.UTF8, "application/xml")
                    //Content = new StringContent(sid.ToString() + "/" + db, Encoding.UTF8, "application/xml")
                };*/
            });
        }

        //https://localhost:4581/api/XML/selectedpartyinvoices?companyno=001&id=2
        [HttpGet]
        [Route("selectedpartyinvoices")]
        public string ListOfSelectedPartyInvoices(int id, long fromdate = 1, long todate = 22000000, string companyno = "001")
        {
            Encoding encoding = Encoding.UTF8; // Specify the desired encoding
            byte[] contentBytes = encoding.GetBytes(Invoice.SelectedPartyTransactionsAsync(companyno,id,fromdate,todate).Result);
            string encodedContent = encoding.GetString(contentBytes);

            ContentResult contentResult = new ContentResult
            {
                Content = encodedContent,
                ContentType = "text/xml",

            };
            Console.WriteLine("ok");
            return contentResult.Content;

            
        }
        //http://localhost:4581/api/xml/ItemWiseAllTransactions
        [HttpGet]
        [Route("ItemWiseAllTransactions")]
        public async Task<string> ItemWiseAllTransactions(long fromdate = 1, long todate = 22000000, string companyno = "001")
        {
            return await Task.Run(() =>
            {

                Encoding encoding = Encoding.UTF8; // Specify the desired encoding
                byte[] contentBytes = encoding.GetBytes(Invoice.ItemWiseAllTransactions(fromdate,todate,companyno));
                string encodedContent = encoding.GetString(contentBytes);

                ContentResult contentResult = new ContentResult
                {
                    Content = encodedContent,
                    ContentType = "text/xml",

                };
                return contentResult.Content;

                /*return new HttpResponseMessage()
                {

                    Content = new StringContent(Invoice.ItemWiseAllTransactions(companyno), Encoding.UTF8, "application/xml")
                };*/
            });
        }
        //https://localhost:4581/api/xml/DeleteInvoice?db=001&Tid=2
        [HttpGet]
        [Route("DeleteInvoice")]
        public string DeleteInvoice(int Tid, string db)
        {
            //int Tid = Convert.ToInt32(HttpContext.Request.Query["Tid"]);
            //string db = HttpContext.Request.Query["db"];
            string basePath = Program.apppath;

            Encoding encoding = Encoding.UTF8; // Specify the desired encoding
            byte[] contentBytes = encoding.GetBytes(Invoice.DeleteTransaction(db, Tid));
            //byte[] contentBytes = encoding.GetBytes("company-" + db + "in-" + Tid);
            string encodedContent = encoding.GetString(contentBytes);

            ContentResult contentResult = new ContentResult
            {
                Content = encodedContent,
                ContentType = "text/xml",

            };
            return contentResult.Content;



        }
        /////----------------------------assets start
        ///
        //http://localhost:4581/api/xml/CreatenewAsset
        [HttpPost]
        [Route("CreatenewAsset")]
        public async Task<string> NewAsset([FromBody] XElement xmlData, int clone, string companyno = "001")
        {
            string basePath = Program.apppath;
            


            var doc = new XmlDocument();
            doc.LoadXml(xmlData.ToString());
            return await Task.Run(() =>
            {
                Encoding encoding = Encoding.UTF8; // Specify the desired encoding
                byte[] contentBytes = encoding.GetBytes(Asset.SaveManyAssetsAsync(companyno, clone, Asset.FromXML(doc.DocumentElement.OuterXml)).Result);
                string encodedContent = encoding.GetString(contentBytes);

                ContentResult contentResult = new ContentResult
                {
                    Content = encodedContent,
                    ContentType = "text/xml",

                };
                return contentResult.Content;
            });
        }

        //https://localhost:4581/api/xml/ListOfAllAssets
        [HttpGet]
        [Route("ListOfAllAssets")]
        public async Task<string> ListOfAllAssets(string companyno = "001")
        {
            string basePath = Program.apppath;

            return await Task.Run(() =>
            {
                Encoding encoding = Encoding.UTF8; // Specify the desired encoding
                byte[] contentBytes = encoding.GetBytes(Asset.AssetstoXML(basePath,companyno));
                string encodedContent = encoding.GetString(contentBytes);

                ContentResult contentResult = new ContentResult
                {
                    Content = encodedContent,
                    ContentType = "text/xml",

                };
                return contentResult.Content;
            });

        }
        //http://localhost:4581/api/XML/deletefa?companyno=001&id=23
        [HttpGet]
        [Route("deletefa")]
        public string deletefaentry(int id, string reson, string companyno = "001")
        {


            Encoding encoding = Encoding.UTF8; // Specify the desired encoding
            byte[] contentBytes = encoding.GetBytes(Asset.DeleteAssetAsync(id, reson, companyno).Result);
            string encodedContent = encoding.GetString(contentBytes);

            ContentResult contentResult = new ContentResult
            {
                Content = encodedContent,
                ContentType = "text/xml",

            };
            return contentResult.Content;
        }

        [HttpPost]
        [Route("CreatenewFAInvoice")]
        public async Task<string> PostFAInvoice([FromBody] XElement xmlData, string companyno = "001")
        {



            var doc = new XmlDocument();
            doc.LoadXml(xmlData.ToString());
            return await Task.Run(() =>
            {

                Encoding encoding = Encoding.UTF8; // Specify the desired encoding
                byte[] contentBytes = encoding.GetBytes(Invoice.SaveFAInvoices(companyno, Invoice.FromXML(doc.DocumentElement.OuterXml)));
                string encodedContent = encoding.GetString(contentBytes);

                ContentResult contentResult = new ContentResult
                {
                    Content = encodedContent,
                    ContentType = "text/xml",

                };
                return contentResult.Content;
            });

        }
        //https://localhost:4581/api/xml/ListOfAllFAInvoices
        [HttpGet]
        [Route("ListOfAllFAInvoices")]
        public async Task<string> GetAllFAInvoices(string companyno = "001")
        {
            string basePath = Program.apppath;

            return await Task.Run(() =>
            {
                Encoding encoding = Encoding.UTF8; // Specify the desired encoding
                byte[] contentBytes = encoding.GetBytes(Asset.FAInvoicestoXML(companyno,"xml"));
                string encodedContent = encoding.GetString(contentBytes);

                ContentResult contentResult = new ContentResult
                {
                    Content = encodedContent,
                    ContentType = "text/xml",

                };
                return contentResult.Content;
            });

        }

        ////////////////////Person*********************
        //http://localhost:4581/xml/CreatenewPerson
        [HttpPost]
        [Route("CreatenewPerson")]
        public async Task<string> CreatenewPerson([FromBody] XElement xmlData, string companyno = "001")
        {

            string basePath = Program.apppath;
            //string companyno = Request.Query["companyno"];


            var doc = new XmlDocument();
            doc.LoadXml(xmlData.ToString());

            return await Task.Run(() =>
            {

                Encoding encoding = Encoding.UTF8; // Specify the desired encoding
                byte[] contentBytes = encoding.GetBytes(Person.SavePerson(companyno, Person.FromXML(doc.DocumentElement.OuterXml)));
                string encodedContent = encoding.GetString(contentBytes);

                ContentResult contentResult = new ContentResult
                {
                    Content = encodedContent,
                    ContentType = "text/xml",

                };
                return contentResult.Content;
            });
        }
        //https://localhost:4581/api/xml/ListOfAllPersons
        [HttpGet]
        [Route("ListOfAllPersons")]
        public async Task<string> ListOfAllPersons(string companyno = "001")
        {
            string basePath = Program.apppath;
            //string companyno = Request.Query["companyno"];
            return await Task.Run(() =>
            {
                Encoding encoding = Encoding.UTF8; // Specify the desired encoding
                byte[] contentBytes = encoding.GetBytes(Person.PersonstoXML(companyno));
                string encodedContent = encoding.GetString(contentBytes);

                ContentResult contentResult = new ContentResult
                {
                    Content = encodedContent,
                    ContentType = "text/xml",

                };
                return contentResult.Content;
            });

        }
        //https://localhost:4581/api/xml/CompanywisePurchasees
        [HttpGet]
        [Route("CompanywisePurchasees")]
        public ActionResult GetCompanywisePurchasees(long fromdate = 1, long todate = 22000000)
        {
            var result = new { data = DataBase.CompanywisePurchasees(fromdate,todate).Result };
            return Ok(result);
        }

        //https://localhost:4581/api/xml/CompanywiseClosingStock
        [HttpGet]
        [Route("CompanywiseClosingStock")]
        public ActionResult GetCompanywiseclosingstock(long fromdate = 1, long todate = 22000000)
        {
            var result = new { data = DataBase.Companywiseclosingstock(fromdate,todate).Result };
            return Ok(result);
        }
    }
}
